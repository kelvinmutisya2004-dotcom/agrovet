# GreenHarvest Agrovet

A developing e-commerce project based on the original GreenHarvest website. The frontend is HTML/CSS/Vanilla JavaScript. The backend uses Node.js built-in HTTP modules and MySQL (no frontend or backend framework).

## Project structure

- `index.html` – storefront page
- `css/` – styles
- `js/` – current storefront JavaScript (still being connected to the API)
- `database/greenharvest.sql` – MySQL database setup and sample catalogue
- `server/` – Node.js API, database connection, admin setup and environment template
- `assets/` – local images and logo

Follow `server/README.md` for the first database/backend setup. The frontend currently retains its prototype product/cart behaviour; the next implementation milestone will connect it to the database API and add customer/admin screens.
