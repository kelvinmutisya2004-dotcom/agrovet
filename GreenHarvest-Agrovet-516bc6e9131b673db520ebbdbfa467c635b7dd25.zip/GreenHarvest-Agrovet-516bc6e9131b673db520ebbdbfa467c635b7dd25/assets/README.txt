Place your own logo and locally stored website images in this folder.
The current prototype still references some images hosted online.
