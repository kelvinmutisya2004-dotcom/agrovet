CREATE DATABASE IF NOT EXISTS greenharvest_db
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE greenharvest_db;

CREATE TABLE IF NOT EXISTS users (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  full_name VARCHAR(120) NOT NULL,
  email VARCHAR(190) NOT NULL UNIQUE,
  phone VARCHAR(30) NULL,
  password_hash VARCHAR(255) NOT NULL,
  role ENUM('customer','admin') NOT NULL DEFAULT 'customer',
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS sessions (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id BIGINT UNSIGNED NOT NULL,
  token_hash CHAR(64) NOT NULL UNIQUE,
  expires_at DATETIME NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_sessions_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_sessions_expiry (expires_at)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS categories (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL UNIQUE,
  slug VARCHAR(110) NOT NULL UNIQUE,
  description VARCHAR(255) NULL,
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS products (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  category_id INT UNSIGNED NOT NULL,
  name VARCHAR(180) NOT NULL,
  description TEXT NULL,
  price DECIMAL(12,2) NOT NULL,
  stock_quantity INT UNSIGNED NOT NULL DEFAULT 0,
  image_url VARCHAR(1000) NULL,
  sku VARCHAR(80) NULL UNIQUE,
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_products_category FOREIGN KEY (category_id) REFERENCES categories(id),
  INDEX idx_products_category (category_id),
  INDEX idx_products_active (is_active)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS orders (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  order_number VARCHAR(32) NOT NULL UNIQUE,
  user_id BIGINT UNSIGNED NOT NULL,
  customer_name VARCHAR(120) NOT NULL,
  customer_phone VARCHAR(30) NOT NULL,
  delivery_address TEXT NOT NULL,
  delivery_notes TEXT NULL,
  subtotal DECIMAL(12,2) NOT NULL,
  delivery_fee DECIMAL(12,2) NOT NULL DEFAULT 0,
  total_amount DECIMAL(12,2) NOT NULL,
  payment_method ENUM('mpesa','cash_on_delivery','manual_mpesa') NOT NULL DEFAULT 'manual_mpesa',
  payment_status ENUM('pending','paid','failed','refunded') NOT NULL DEFAULT 'pending',
  order_status ENUM('pending','confirmed','processing','ready','dispatched','delivered','cancelled') NOT NULL DEFAULT 'pending',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_orders_user FOREIGN KEY (user_id) REFERENCES users(id),
  INDEX idx_orders_user (user_id),
  INDEX idx_orders_status (order_status)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS order_items (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  order_id BIGINT UNSIGNED NOT NULL,
  product_id BIGINT UNSIGNED NULL,
  product_name VARCHAR(180) NOT NULL,
  unit_price DECIMAL(12,2) NOT NULL,
  quantity INT UNSIGNED NOT NULL,
  line_total DECIMAL(12,2) NOT NULL,
  CONSTRAINT fk_order_items_order FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
  CONSTRAINT fk_order_items_product FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS payments (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  order_id BIGINT UNSIGNED NOT NULL,
  provider VARCHAR(40) NOT NULL DEFAULT 'manual',
  transaction_reference VARCHAR(100) NULL,
  amount DECIMAL(12,2) NOT NULL,
  status ENUM('pending','successful','failed') NOT NULL DEFAULT 'pending',
  provider_response JSON NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_payments_order FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
  INDEX idx_payment_reference (transaction_reference)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS business_settings (
  setting_key VARCHAR(100) PRIMARY KEY,
  setting_value TEXT NULL,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

INSERT IGNORE INTO categories (name, slug, description) VALUES
('Animal Feeds','feeds','Feeds and nutrition for livestock and poultry'),
('Veterinary Products','veterinary','Animal health and veterinary supplies'),
('Seeds & Seedlings','seeds','Crop seeds and seedlings'),
('Fertilizers & Chemicals','fertilizers','Fertilizers and crop protection supplies');

INSERT IGNORE INTO business_settings (setting_key, setting_value) VALUES
('business_name','GreenHarvest Agrovet'),
('business_phone',''),
('business_email',''),
('business_location',''),
('mpesa_till_number',''),
('delivery_fee','0');

-- Sample catalogue records from the supplied website prototype.
INSERT INTO products (category_id, name, description, price, stock_quantity, image_url, sku)
SELECT c.id, p.name, 'Sample product - update description, price and stock in the admin area.', p.price, 0, p.image_url, p.sku
FROM (
  SELECT 'feeds' slug,'Dairy Meal 50kg' name,2800.00 price,'https://images.unsplash.com/photo-1500382017468-9049fed747ef?w=500' image_url,'GH-FEED-001' sku UNION ALL
  SELECT 'feeds','Chick Mash 50kg',3200.00,'https://images.unsplash.com/photo-1548550023-2bdb3c5beed7?w=500','GH-FEED-002' UNION ALL
  SELECT 'veterinary','Poultry Vitamins',450.00,'https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?w=500','GH-VET-001' UNION ALL
  SELECT 'veterinary','Animal Dewormer',650.00,'https://images.unsplash.com/photo-1584820927498-cfe5211fd8bf?w=500','GH-VET-002' UNION ALL
  SELECT 'seeds','Hybrid Maize Seeds',850.00,'https://images.unsplash.com/photo-1551754655-cd27e38d2076?w=500','GH-SEED-001' UNION ALL
  SELECT 'seeds','Tomato Seeds',250.00,'https://images.unsplash.com/photo-1592841200221-a6898f307baa?w=500','GH-SEED-002' UNION ALL
  SELECT 'fertilizers','NPK Fertilizer 50kg',4500.00,'https://images.unsplash.com/photo-1589923188900-85dae523342b?w=500','GH-FERT-001' UNION ALL
  SELECT 'fertilizers','Organic Fertilizer',1200.00,'https://images.unsplash.com/photo-1416879595882-3373a0480b5b?w=500','GH-FERT-002'
) p JOIN categories c ON c.slug = p.slug
WHERE NOT EXISTS (SELECT 1 FROM products existing WHERE existing.sku = p.sku);
