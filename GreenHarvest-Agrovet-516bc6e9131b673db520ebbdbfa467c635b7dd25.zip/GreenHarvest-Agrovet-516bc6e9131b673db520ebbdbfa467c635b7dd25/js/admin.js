
let adminProducts = [];
let adminCategories = [];
let posCart = [];

document.addEventListener('DOMContentLoaded', async () => {
    setupImageUpload();

    document.getElementById('product-form')
        .addEventListener('submit', saveProduct);

    setupPOS();

    await checkAdminAccess();
});

// Reusable API request function
async function apiRequest(url, options = {}) {
    const response = await fetch(url, {
        credentials: 'same-origin',
        ...options,
        headers: {
            ...(options.body instanceof FormData
                ? {}
                : { 'Content-Type': 'application/json' }),
            ...(options.headers || {})
        }
    });

    const data = await response.json().catch(() => ({}));

    if (!response.ok) {
        throw new Error(data.error || data.message || 'Something went wrong.');
    }

    return data;
}

// Check administrator access
async function checkAdminAccess() {
    try {
        const data = await apiRequest('/api/auth/me');

        if (!data.user) {
            window.location.href = 'login.html';
            return;
        }

        if (data.user.role !== 'admin') {
            alert('Access denied. Administrator privileges are required.');
            window.location.href = 'index.html';
            return;
        }

        document.getElementById('admin-name').textContent =
            data.user.full_name;

        await Promise.all([
    loadAdminCategories(),
    loadAdminProducts(),
    loadDashboardStats(),
    loadAdminOrders(),
    loadInventoryAlerts()
]);

    } catch (error) {
        console.error(error);
        alert('Unable to verify administrator access. Please log in again.');
        window.location.href = 'login.html';
    }
}

// Set up product photo selection and preview
function setupImageUpload() {
    const photoInput = document.getElementById('product-photo');
    const preview = document.getElementById('image-preview');

    if (!photoInput || !preview) {
        console.error('Product photo input or preview element is missing.');
        return;
    }

    photoInput.addEventListener('change', () => {
        const file = photoInput.files[0];

        if (!file) return;

        const allowedTypes = [
            'image/jpeg',
            'image/png',
            'image/webp'
        ];

        if (!allowedTypes.includes(file.type)) {
            alert('Please select a JPG, PNG or WEBP image.');
            photoInput.value = '';
            return;
        }

        if (file.size > 3 * 1024 * 1024) {
            alert('The image must not exceed 3 MB.');
            photoInput.value = '';
            return;
        }

        const reader = new FileReader();

        reader.onload = () => {
            preview.src = reader.result;
            preview.style.display = 'block';
        };

        reader.onerror = () => {
            alert('Could not preview the selected image.');
        };

        reader.readAsDataURL(file);
    });
}

// Upload selected product photo
async function uploadProductImage() {
    const photoInput = document.getElementById('product-photo');
    const file = photoInput.files[0];

    if (!file) {
        return document.getElementById('product-image').value.trim();
    }

    const allowedTypes = [
        'image/jpeg',
        'image/png',
        'image/webp'
    ];

    if (!allowedTypes.includes(file.type)) {
        throw new Error('Please select a JPG, PNG or WEBP image.');
    }

    if (file.size > 3 * 1024 * 1024) {
        throw new Error('The image must not exceed 3 MB.');
    }

    const reader = new FileReader();

    const imageData = await new Promise((resolve, reject) => {
        reader.onload = () => resolve(reader.result);
        reader.onerror = () => reject(new Error('Could not read the image.'));
        reader.readAsDataURL(file);
    });

    const result = await apiRequest('/api/admin/upload-product-image', {
        method: 'POST',
        body: JSON.stringify({ image: imageData })
    });

    return result.imageUrl;
}

// Load product categories
async function loadAdminCategories() {
    try {
        const data = await apiRequest('/api/categories');
        adminCategories = data.categories || [];

        const select = document.getElementById('product-category');
        select.innerHTML = '<option value="">Select category</option>';

        adminCategories.forEach(category => {
            const option = document.createElement('option');
            option.value = category.id;
            option.textContent = category.name;
            select.appendChild(option);
        });

    } catch (error) {
        console.error('Category loading error:', error);
        showProductMessage('Could not load product categories.', true);
    }
}

// Load products from database
async function loadAdminProducts() {
    const table = document.getElementById('admin-products');
    table.innerHTML = '<tr><td colspan="5">Loading products...</td></tr>';

    try {
        const data = await apiRequest('/api/products');
        adminProducts = data.products || [];
        renderPOSProducts();

        if (adminProducts.length === 0) {
            table.innerHTML =
                '<tr><td colspan="5">No products found.</td></tr>';
            return;
        }

        table.innerHTML = '';

        adminProducts.forEach(product => {
            const row = document.createElement('tr');

            const nameCell = document.createElement('td');
            nameCell.textContent = product.name;

            const categoryCell = document.createElement('td');
            categoryCell.textContent = product.category || 'Uncategorised';

            const priceCell = document.createElement('td');
            priceCell.textContent =
                `KSh ${Number(product.price).toLocaleString()}`;

            const stockCell = document.createElement('td');
            stockCell.textContent = product.stock_quantity;

            const actionCell = document.createElement('td');

            const editButton = document.createElement('button');
            editButton.textContent = 'Edit';
            editButton.type = 'button';
            editButton.onclick = () => editProduct(product.id);

            const deleteButton = document.createElement('button');
            deleteButton.textContent = 'Delete';
            deleteButton.type = 'button';
            deleteButton.style.marginLeft = '8px';
            deleteButton.onclick = () => deleteProduct(product.id);

            actionCell.append(editButton, deleteButton);

            row.append(
                nameCell,
                categoryCell,
                priceCell,
                stockCell,
                actionCell
            );

            table.appendChild(row);
        });

    } catch (error) {
        console.error('Product loading error:', error);
        table.innerHTML =
            '<tr><td colspan="5">Could not load products.</td></tr>';
    }
}

// Load inventory alerts from the backend

// Load inventory alerts from the backend
async function loadInventoryAlerts() {
    const table = document.getElementById('inventory-alert-products');
    const message = document.getElementById('inventory-alert-message');

    if (!table) return;

    table.innerHTML = `
        <tr>
            <td colspan="6">Loading inventory alerts...</td>
        </tr>
    `;

    if (message) {
        message.textContent = '';
    }

    try {
        const data = await apiRequest('/api/admin/inventory-alerts');

        const summary = data.summary || {};
        const products = data.products || [];

        document.getElementById('inventory-out-of-stock').textContent =
            Number(summary.outOfStock || 0);

        document.getElementById('inventory-low-stock').textContent =
            Number(summary.lowStock || 0);

        document.getElementById('inventory-total-alerts').textContent =
            Number(summary.totalAlerts || 0);

        table.innerHTML = '';

        if (products.length === 0) {
            table.innerHTML = `
                <tr>
                    <td colspan="6">
                        All products have sufficient stock. No inventory alerts.
                    </td>
                </tr>
            `;
            return;
        }

        products.forEach(product => {
            const row = document.createElement('tr');

            const nameCell = document.createElement('td');
            nameCell.textContent = product.name;

            const skuCell = document.createElement('td');
            skuCell.textContent = product.sku || '-';

            const stockCell = document.createElement('td');
            stockCell.textContent = product.stock_quantity;

            const thresholdCell = document.createElement('td');
            thresholdCell.textContent = product.low_stock_threshold;

            const statusCell = document.createElement('td');
            const status = document.createElement('strong');

            if (product.alert_type === 'out_of_stock') {
                status.textContent = 'OUT OF STOCK';
                status.style.color = '#c62828';
            } else {
                status.textContent = 'LOW STOCK';
                status.style.color = '#e68a00';
            }

            statusCell.appendChild(status);

            const actionCell = document.createElement('td');

            const restockButton = document.createElement('button');
            restockButton.type = 'button';
            restockButton.textContent = 'Restock';

            restockButton.addEventListener('click', () => {
                openRestockDialog(product);
            });

            actionCell.appendChild(restockButton);

            row.append(
                nameCell,
                skuCell,
                stockCell,
                thresholdCell,
                statusCell,
                actionCell
            );

            table.appendChild(row);
        });

    } catch (error) {
        console.error('Inventory alerts error:', error);

        table.innerHTML = `
            <tr>
                <td colspan="6">
                    Could not load inventory alerts.
                </td>
            </tr>
        `;

        if (message) {
            message.textContent = error.message;
            message.style.color = 'red';
        }
    }
}

// Open the stock restocking form

// Open the stock restocking form
function openRestockDialog(product) {
    document.getElementById('restock-dialog-overlay')?.remove();

    const overlay = document.createElement('div');
    overlay.id = 'restock-dialog-overlay';

    Object.assign(overlay.style, {
        position: 'fixed',
        inset: '0',
        background: 'rgba(0,0,0,0.55)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        padding: '20px',
        zIndex: '9999'
    });

    const dialog = document.createElement('div');

    Object.assign(dialog.style, {
        background: '#fff',
        color: '#222',
        padding: '24px',
        borderRadius: '10px',
        width: '100%',
        maxWidth: '420px',
        boxSizing: 'border-box'
    });

    const heading = document.createElement('h3');
    heading.textContent = 'Restock Product';

    const productName = document.createElement('p');
    productName.textContent = product.name;

    const currentStock = document.createElement('p');
    currentStock.textContent = `Current stock: ${product.stock_quantity}`;

    const form = document.createElement('form');

    const quantityLabel = document.createElement('label');
    quantityLabel.textContent = 'Quantity received';
    quantityLabel.style.display = 'block';
    quantityLabel.style.marginTop = '15px';

    const quantityInput = document.createElement('input');
    quantityInput.type = 'number';
    quantityInput.min = '1';
    quantityInput.max = '1000000';
    quantityInput.step = '1';
    quantityInput.required = true;
    quantityInput.placeholder = 'Enter quantity received';
    quantityInput.style.width = '100%';
    quantityInput.style.padding = '10px';
    quantityInput.style.marginTop = '6px';
    quantityInput.style.boxSizing = 'border-box';

    const notesLabel = document.createElement('label');
    notesLabel.textContent = 'Notes (optional)';
    notesLabel.style.display = 'block';
    notesLabel.style.marginTop = '15px';

    const notesInput = document.createElement('textarea');
    notesInput.maxLength = 255;
    notesInput.placeholder = 'e.g. Stock received from supplier';
    notesInput.rows = 3;
    notesInput.style.width = '100%';
    notesInput.style.padding = '10px';
    notesInput.style.marginTop = '6px';
    notesInput.style.boxSizing = 'border-box';

    const errorMessage = document.createElement('p');
    errorMessage.style.color = 'red';

    const buttonContainer = document.createElement('div');
    buttonContainer.style.display = 'flex';
    buttonContainer.style.gap = '10px';
    buttonContainer.style.marginTop = '15px';

    const saveButton = document.createElement('button');
    saveButton.type = 'submit';
    saveButton.textContent = 'Save Restock';

    const cancelButton = document.createElement('button');
    cancelButton.type = 'button';
    cancelButton.textContent = 'Cancel';

    cancelButton.addEventListener('click', () => {
        overlay.remove();
    });

    buttonContainer.append(saveButton, cancelButton);

    form.append(
        quantityLabel,
        quantityInput,
        notesLabel,
        notesInput,
        errorMessage,
        buttonContainer
    );

    form.addEventListener('submit', async event => {
        event.preventDefault();

        const quantity = Number(quantityInput.value);
        const notes = notesInput.value.trim();

        if (
            !Number.isInteger(quantity) ||
            quantity < 1 ||
            quantity > 1000000
        ) {
            errorMessage.textContent =
                'Enter a whole number between 1 and 1,000,000.';
            return;
        }

        saveButton.disabled = true;
        saveButton.textContent = 'Saving...';
        errorMessage.textContent = '';

        try {
            const result = await apiRequest(
                `/api/admin/products/${product.id}/restock`,
                {
                    method: 'POST',
                    body: JSON.stringify({
                        quantity,
                        notes
                    })
                }
            );

            const message = document.getElementById(
                'inventory-alert-message'
            );

            if (message) {
                message.textContent =
                    `${result.product.name}: stock increased from ` +
                    `${result.product.previousStock} to ` +
                    `${result.product.newStock}.`;

                message.style.color = 'green';
            }

            await Promise.all([
                loadInventoryAlerts(),
                loadAdminProducts(),
                loadDashboardStats()
            ]);

            overlay.remove();

        } catch (error) {
            console.error('Restocking error:', error);

            errorMessage.textContent = error.message;
            saveButton.disabled = false;
            saveButton.textContent = 'Save Restock';
        }
    });

    dialog.append(
        heading,
        productName,
        currentStock,
        form
    );

    overlay.appendChild(dialog);
    document.body.appendChild(overlay);

    quantityInput.focus();
}



// Load dashboard statistics
async function loadDashboardStats() {
    try {
        const data = await apiRequest('/api/admin/dashboard-stats');
        const stats = data.stats;

        document.getElementById('total-products').textContent =
            Number(stats.totalProducts).toLocaleString();

        document.getElementById('total-orders').textContent =
            Number(stats.totalOrders).toLocaleString();

        document.getElementById('total-customers').textContent =
            Number(stats.totalCustomers).toLocaleString();

        document.getElementById('total-sales').textContent =
            'KSh ' + Number(stats.totalSales).toLocaleString('en-KE', {
                minimumFractionDigits: 2,
                maximumFractionDigits: 2
            });

    } catch (error) {
        console.error('Dashboard statistics error:', error);
    }
}

// Add or update product
async function saveProduct(event) {
    event.preventDefault();

    const productId = document.getElementById('product-id').value;

    const product = {
        name: document.getElementById('product-name').value.trim(),
        price: Number(document.getElementById('product-price').value),
        stockQuantity: Number(document.getElementById('product-stock').value),
        lowStockThreshold: Number(
    document.getElementById('product-low-stock-threshold').value
),
        categoryId: Number(document.getElementById('product-category').value),
        imageUrl: document.getElementById('product-image').value.trim(),
        sku: document.getElementById('product-sku').value.trim(),
        description: document.getElementById('product-description').value.trim(),
        isActive: true
    };

    if (
        !product.name ||
        !product.categoryId ||
        !Number.isFinite(product.price) ||
        product.price <= 0 ||
        !Number.isInteger(product.stockQuantity) ||
product.stockQuantity < 0 ||
!Number.isInteger(product.lowStockThreshold) ||
product.lowStockThreshold < 0
    ) {
        showProductMessage(
            'Enter a valid name, category, price and stock quantity.',
            true
        );
        return;
    }

    const saveButton = document.getElementById('save-product');
    saveButton.disabled = true;
    saveButton.textContent = 'Saving...';

    try {
        product.imageUrl = await uploadProductImage();

        if (productId) {
            await apiRequest(`/api/admin/products/${productId}`, {
                method: 'PUT',
                body: JSON.stringify(product)
            });

            showProductMessage('Product updated successfully.');

        } else {
            await apiRequest('/api/admin/products', {
                method: 'POST',
                body: JSON.stringify(product)
            });

            showProductMessage('Product added successfully.');
        }

        resetProductForm();

       await Promise.all([
    loadAdminProducts(),
    loadDashboardStats(),
    loadInventoryAlerts()
]);

    } catch (error) {
        showProductMessage(error.message, true);

    } finally {
        saveButton.disabled = false;
        saveButton.textContent = 'Save Product';
    }
}

// Edit product
function editProduct(id) {
    const product = adminProducts.find(item => item.id === id);

    if (!product) return;

    const category = adminCategories.find(
        item => item.slug === product.category_slug
    );

    document.getElementById('product-id').value = product.id;
    document.getElementById('product-name').value = product.name;
    document.getElementById('product-price').value = product.price;
    document.getElementById('product-stock').value = product.stock_quantity;
    document.getElementById('product-low-stock-threshold').value =
    product.low_stock_threshold ?? 5;
    document.getElementById('product-category').value =
        category ? category.id : '';

    document.getElementById('product-image').value =
        product.image_url || '';

    document.getElementById('product-sku').value = product.sku || '';

    document.getElementById('product-description').value =
        product.description || '';

    const preview = document.getElementById('image-preview');

    if (product.image_url) {
        preview.src = product.image_url;
        preview.style.display = 'block';
    } else {
        preview.style.display = 'none';
        preview.removeAttribute('src');
    }

    document.getElementById('product-photo').value = '';

    document.getElementById('save-product').textContent = 'Update Product';

    document.getElementById('product-form').scrollIntoView({
        behavior: 'smooth'
    });

    showProductMessage('Editing: ' + product.name);
}

// Delete product
async function deleteProduct(id) {
    const product = adminProducts.find(item => item.id === id);

    if (!product) return;

    const confirmed = confirm(
        `Are you sure you want to remove "${product.name}"?`
    );

    if (!confirmed) return;

    try {
        await apiRequest(`/api/admin/products/${id}`, {
            method: 'DELETE'
        });

        showProductMessage('Product removed successfully.');

        await Promise.all([
            loadAdminProducts(),
            loadDashboardStats()
        ]);

    } catch (error) {
        showProductMessage(error.message, true);
    }
}

// Reset product form
function resetProductForm() {
    document.getElementById('product-form').reset();
    document.getElementById('product-id').value = '';

    const preview = document.getElementById('image-preview');
    preview.style.display = 'none';
    preview.removeAttribute('src');

    document.getElementById('save-product').textContent = 'Save Product';
}

// Display product messages
function showProductMessage(message, isError = false) {
    const element = document.getElementById('product-message');
    element.textContent = message;
    element.style.color = isError ? 'red' : 'green';
}

// Administrator logout
async function adminLogout() {
    try {
        await apiRequest('/api/auth/logout', {
            method: 'POST',
            body: JSON.stringify({})
        });
    } catch (error) {
        console.error('Logout error:', error);
    }

    window.location.href = 'login.html';
}

// Load customer orders
async function loadAdminOrders() {
    const container = document.getElementById('recent-orders');

    if (!container) return;

    container.textContent = 'Loading orders...';

    try {
        const data = await apiRequest('/api/admin/orders');
        const orders = data.orders || [];

        if (orders.length === 0) {
            container.textContent = 'No customer orders have been placed yet.';
            return;
        }

        const table = document.createElement('table');
        table.style.width = '100%';

        const headers = [
            'Order Number',
            'Customer',
            'Phone',
            'Total',
            'Payment',
            'Order Status',
            'Date',
            'Action'
        ];

        const thead = document.createElement('thead');
        const headerRow = document.createElement('tr');

        headers.forEach(header => {
            const th = document.createElement('th');
            th.textContent = header;
            headerRow.appendChild(th);
        });

        thead.appendChild(headerRow);
        table.appendChild(thead);

        const tbody = document.createElement('tbody');

        orders.forEach(order => {
            const row = document.createElement('tr');

            const values = [
                order.order_number,
                order.customer_name,
                order.customer_phone,
                `KSh ${Number(order.total_amount).toLocaleString()}`,
                order.payment_status,
                null,
                new Date(order.created_at).toLocaleDateString(),
                null
            ];

            values.forEach((value, index) => {
                const cell = document.createElement('td');

                if (index !== 5 && index !== 7) {
                    cell.textContent = value ?? '-';
                }

                if (index === 5) {
                    const select = document.createElement('select');

                    const statuses = [
                        'pending',
                        'confirmed',
                        'processing',
                        'ready',
                        'dispatched',
                        'delivered',
                        'cancelled'
                    ];

                    statuses.forEach(status => {
                        const option = document.createElement('option');
                        option.value = status;
                        option.textContent =
                            status.charAt(0).toUpperCase() + status.slice(1);

                        if (status === order.order_status) {
                            option.selected = true;
                        }

                        select.appendChild(option);
                    });

                    cell.appendChild(select);
                    row.appendChild(cell);
                    row.dataset.orderId = order.id;
                    row.dataset.newStatus = order.order_status;

                    select.addEventListener('change', () => {
                        row.dataset.newStatus = select.value;
                    });

                    return;
                }

                if (index === 7) {
                    const button = document.createElement('button');
                    button.type = 'button';
                    button.textContent = 'Update';
                    button.addEventListener('click', () => {
                        updateOrderStatus(
                            order.id,
                            row.dataset.newStatus
                        );
                    });

                    cell.appendChild(button);
                }

                row.appendChild(cell);
            });

            tbody.appendChild(row);
        });

        table.appendChild(tbody);

        container.innerHTML = '';
        container.appendChild(table);

    } catch (error) {
        console.error('Order loading error:', error);
        container.textContent = 'Could not load customer orders.';
    }
}

// Update an order's status
async function updateOrderStatus(orderId, status) {
    const confirmed = confirm(
        `Are you sure you want to change this order's status to "${status}"?`
    );

    if (!confirmed) return;

    try {
        await apiRequest(`/api/admin/orders/${orderId}/status`, {
            method: 'PATCH',
            body: JSON.stringify({ status })
        });

        alert('Order status updated successfully.');

        await loadAdminOrders();

    } catch (error) {
        alert(error.message);
    }
}

// ========================================
// POINT OF SALE (POS) FUNCTIONALITY
// ========================================

// Set up POS event listeners
function setupPOS() {
    const search = document.getElementById('pos-search');
    const discount = document.getElementById('pos-discount');
    const paymentMethod = document.getElementById('pos-payment-method');
    const completeButton = document.getElementById('pos-complete-sale');

    if (!search || !discount || !paymentMethod || !completeButton) {
        console.error('POS HTML elements are missing.');
        return;
    }

    search.addEventListener('input', renderPOSProducts);
    discount.addEventListener('input', updatePOSCart);
    paymentMethod.addEventListener('change', togglePOSPaymentFields);

    // Checkout will be connected to the database in the next stage.
    completeButton.addEventListener('click', () => {
        alert('The POS cart is ready. Database checkout and payment confirmation will be connected in the next stage.');
    });

    togglePOSPaymentFields();
}

// Display products in POS
function renderPOSProducts() {
    const container = document.getElementById('pos-products');

    if (!container) return;

    const searchTerm = (
        document.getElementById('pos-search')?.value || ''
    ).trim().toLowerCase();

    const filteredProducts = adminProducts.filter(product => {
        const name = (product.name || '').toLowerCase();
        const category = (product.category || '').toLowerCase();

        return name.includes(searchTerm) ||
               category.includes(searchTerm);
    });

    container.innerHTML = '';

    if (filteredProducts.length === 0) {
        container.innerHTML =
            '<p class="pos-empty">No matching products found.</p>';
        return;
    }

    filteredProducts.forEach(product => {
        const card = document.createElement('div');
        card.className = 'pos-product';

        if (product.image_url) {
            const image = document.createElement('img');
            image.src = product.image_url;
            image.alt = product.name;
            image.loading = 'lazy';
            card.appendChild(image);
        }

        const name = document.createElement('h4');
        name.textContent = product.name;

        const price = document.createElement('p');
        price.textContent =
            `KSh ${Number(product.price).toLocaleString('en-KE', {
                minimumFractionDigits: 2,
                maximumFractionDigits: 2
            })}`;

        const stock = document.createElement('small');
        stock.textContent =
            `Available stock: ${product.stock_quantity}`;

        const button = document.createElement('button');
        button.type = 'button';
        button.textContent =
            Number(product.stock_quantity) > 0
                ? 'Add to Sale'
                : 'Out of Stock';

        button.disabled = Number(product.stock_quantity) <= 0;
        button.addEventListener('click', () => addPOSProduct(product.id));

        card.append(name, price, stock, button);
        container.appendChild(card);
    });
}

// Add product to current sale
function addPOSProduct(productId) {
    const product = adminProducts.find(
        item => Number(item.id) === Number(productId)
    );

    if (!product) return;

    const existingItem = posCart.find(
        item => Number(item.productId) === Number(productId)
    );

    const currentQuantity = existingItem
        ? existingItem.quantity
        : 0;

    if (currentQuantity >= Number(product.stock_quantity)) {
        alert('You cannot add more than the available stock.');
        return;
    }

    if (existingItem) {
        existingItem.quantity += 1;
    } else {
        posCart.push({
            productId: Number(product.id),
            name: product.name,
            price: Number(product.price),
            quantity: 1,
            availableStock: Number(product.stock_quantity)
        });
    }

    updatePOSCart();
}

// Change product quantity
function changePOSQuantity(productId, change) {
    const item = posCart.find(
        product => product.productId === Number(productId)
    );

    if (!item) return;

    const newQuantity = item.quantity + change;

    if (newQuantity <= 0) {
        removePOSProduct(productId);
        return;
    }

    if (newQuantity > item.availableStock) {
        alert('You cannot exceed the available stock.');
        return;
    }

    item.quantity = newQuantity;
    updatePOSCart();
}

// Remove product from sale
function removePOSProduct(productId) {
    posCart = posCart.filter(
        item => item.productId !== Number(productId)
    );

    updatePOSCart();
}

// Calculate and display POS totals
function updatePOSCart() {
    const cartTable = document.getElementById('pos-cart');

    if (!cartTable) return;

    cartTable.innerHTML = '';

    if (posCart.length === 0) {
        cartTable.innerHTML = `
            <tr>
                <td colspan="4" class="pos-empty">
                    No products added yet.
                </td>
            </tr>
        `;
    } else {
        posCart.forEach(item => {
            const row = document.createElement('tr');

            const nameCell = document.createElement('td');
            nameCell.textContent = item.name;

            const quantityCell = document.createElement('td');

            const quantityControls = document.createElement('div');
            quantityControls.className = 'pos-quantity';

            const decreaseButton = document.createElement('button');
            decreaseButton.type = 'button';
            decreaseButton.textContent = '-';
            decreaseButton.addEventListener('click', () => {
                changePOSQuantity(item.productId, -1);
            });

            const quantityText = document.createElement('span');
            quantityText.textContent = item.quantity;

            const increaseButton = document.createElement('button');
            increaseButton.type = 'button';
            increaseButton.textContent = '+';
            increaseButton.addEventListener('click', () => {
                changePOSQuantity(item.productId, 1);
            });

            quantityControls.append(
                decreaseButton,
                quantityText,
                increaseButton
            );

            quantityCell.appendChild(quantityControls);

            const totalCell = document.createElement('td');
            totalCell.textContent =
                `KSh ${(item.price * item.quantity).toLocaleString('en-KE', {
                    minimumFractionDigits: 2,
                    maximumFractionDigits: 2
                })}`;

            const actionCell = document.createElement('td');

            const removeButton = document.createElement('button');
            removeButton.type = 'button';
            removeButton.className = 'pos-remove';
            removeButton.textContent = '×';
            removeButton.title = 'Remove product';
            removeButton.addEventListener('click', () => {
                removePOSProduct(item.productId);
            });

            actionCell.appendChild(removeButton);

            row.append(
                nameCell,
                quantityCell,
                totalCell,
                actionCell
            );

            cartTable.appendChild(row);
        });
    }

    const subtotal = posCart.reduce(
        (sum, item) => sum + item.price * item.quantity,
        0
    );

    const discountInput = document.getElementById('pos-discount');
    let discount = Number(discountInput.value);

    if (!Number.isFinite(discount) || discount < 0) {
        discount = 0;
    }

    // A discount cannot exceed the subtotal.
    discount = Math.min(discount, subtotal);

    const total = Math.max(0, subtotal - discount);

    document.getElementById('pos-subtotal').textContent =
        formatPOSMoney(subtotal);

    document.getElementById('pos-discount-display').textContent =
        formatPOSMoney(discount);

    document.getElementById('pos-total').textContent =
        formatPOSMoney(total);

    renderPOSProducts();
}

// Format Kenyan shillings
function formatPOSMoney(amount) {
    return 'KSh ' + Number(amount).toLocaleString('en-KE', {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    });
}

// Show M-Pesa transaction field only when M-Pesa is selected
function togglePOSPaymentFields() {
    const method = document.getElementById('pos-payment-method');
    const mpesaField = document.getElementById('pos-mpesa-field');

    if (!method || !mpesaField) return;

    mpesaField.hidden = method.value !== 'mpesa';
}
