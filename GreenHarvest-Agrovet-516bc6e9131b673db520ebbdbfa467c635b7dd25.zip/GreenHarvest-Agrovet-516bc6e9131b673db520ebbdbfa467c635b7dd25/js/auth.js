
const registerForm = document.getElementById('register-form');
const loginForm = document.getElementById('login-form');

// Determine where the logged-in user should go
async function redirectAfterLogin() {
    const response = await fetch('/api/auth/me', {
        credentials: 'same-origin'
    });

    const data = await response.json();

    if (!response.ok || !data.user) {
        throw new Error('Could not verify your account. Please try logging in again.');
    }

    if (data.user.role === 'admin') {
        window.location.href = 'admin.html';
    } else {
        window.location.href = 'index.html';
    }
}

// Customer registration
if (registerForm) {
    registerForm.addEventListener('submit', async (event) => {
        event.preventDefault();

        const message = document.getElementById('message');

        const userData = {
            fullName: document.getElementById('name').value.trim(),
            email: document.getElementById('email').value.trim(),
            phone: document.getElementById('phone').value.trim(),
            password: document.getElementById('password').value
        };

        try {
            const response = await fetch('/api/auth/register', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(userData)
            });

            const data = await response.json();

            if (!response.ok) {
                throw new Error(data.error || 'Registration failed.');
            }

            message.style.color = 'green';
            message.textContent = 'Account created successfully! Redirecting...';

            setTimeout(() => {
                window.location.href = 'index.html';
            }, 1000);

        } catch (error) {
            message.style.color = 'red';
            message.textContent = error.message;
        }
    });
}

// Login for both administrators and customers
if (loginForm) {
    loginForm.addEventListener('submit', async (event) => {
        event.preventDefault();

        const message = document.getElementById('message');

        const loginData = {
            email: document.getElementById('email').value.trim(),
            password: document.getElementById('password').value
        };

        const loginButton = loginForm.querySelector('button[type="submit"]');

        if (loginButton) {
            loginButton.disabled = true;
        }

        try {
            const response = await fetch('/api/auth/login', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                credentials: 'same-origin',
                body: JSON.stringify(loginData)
            });

            const data = await response.json();

            if (!response.ok) {
                throw new Error(data.error || 'Login failed.');
            }

            message.style.color = 'green';
            message.textContent = 'Login successful! Redirecting...';

            await redirectAfterLogin();

        } catch (error) {
            message.style.color = 'red';
            message.textContent = error.message;

            if (loginButton) {
                loginButton.disabled = false;
            }
        }
    });
}

// Google Sign-In
window.handleGoogleCredential = async function (response) {
    const message = document.getElementById('message');

    try {
        message.style.color = 'black';
        message.textContent = 'Signing in with Google...';

        const result = await fetch('/api/auth/google', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            credentials: 'same-origin',
            body: JSON.stringify({
                credential: response.credential
            })
        });

        const data = await result.json();

        if (!result.ok) {
            throw new Error(data.error || 'Google login failed.');
        }

        message.style.color = 'green';
        message.textContent = 'Google login successful! Redirecting...';

        await redirectAfterLogin();

    } catch (error) {
        message.style.color = 'red';
        message.textContent = error.message;
    }
};

// Display the logged-in user's account information
async function loadCustomerAccount() {
    const accountArea = document.getElementById('account-area');

    if (!accountArea) return;

    try {
        const response = await fetch('/api/auth/me', {
            credentials: 'same-origin'
        });

        const data = await response.json();

        if (data.user) {
            if (data.user.role === 'admin') {
                accountArea.innerHTML = `
                    <a href="admin.html">Admin Dashboard</a>
                    <button type="button" id="logout-btn">Logout</button>
                `;
            } else {
                accountArea.innerHTML = `
                    <span>Welcome, ${escapeHtml(data.user.full_name)}</span>
                    <button type="button" id="logout-btn">Logout</button>
                `;
            }

            document.getElementById('logout-btn')
                .addEventListener('click', logoutCustomer);

        } else {
            accountArea.innerHTML = `
                <a href="login.html">Login</a>
                <a href="register.html">Register</a>
            `;
        }

    } catch (error) {
        console.error('Could not load account information:', error);
    }
}

// Escape user-provided text before displaying it
function escapeHtml(value) {
    return String(value).replace(/[&<>"']/g, character => ({
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#39;'
    })[character]);
}

// Log out the current user
async function logoutCustomer() {
    try {
        const response = await fetch('/api/auth/logout', {
            method: 'POST',
            credentials: 'same-origin'
        });

        if (!response.ok) {
            throw new Error('Logout failed.');
        }

        window.location.href = 'index.html';

    } catch (error) {
        alert(error.message);
    }
}

document.addEventListener('DOMContentLoaded', loadCustomerAccount);
