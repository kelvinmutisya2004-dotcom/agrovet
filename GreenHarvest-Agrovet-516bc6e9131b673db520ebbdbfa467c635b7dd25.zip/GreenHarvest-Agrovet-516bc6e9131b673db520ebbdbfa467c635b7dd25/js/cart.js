
// ADD TO CART
function addToCart(id) {
    const product = products.find(p => p.id === id);

    if (!product) return;

    const existing = cart.find(p => p.id === id);

    if (existing) {
        existing.quantity++;
    } else {
        cart.push({ ...product, quantity: 1 });
    }

    updateCart();
}

// UPDATE CART
function updateCart() {
    const cartItems = document.getElementById("cart-items");

    cartItems.innerHTML = "";

    let total = 0;
    let count = 0;

    cart.forEach(item => {
        const subtotal = item.price * item.quantity;

        total += subtotal;
        count += item.quantity;

        cartItems.innerHTML += `
            <div class="cart-item">
                <div class="cart-item-details">
                    <strong>${item.name}</strong>

                    <p>KSh ${item.price.toLocaleString()} each</p>

                    <div class="quantity-controls">
                        <button onclick="changeQuantity(${item.id}, -1)">
                            −
                        </button>

                        <span>${item.quantity}</span>

                        <button onclick="changeQuantity(${item.id}, 1)">
                            +
                        </button>
                    </div>

                    <p class="item-subtotal">
                        Subtotal: KSh ${subtotal.toLocaleString()}
                    </p>
                </div>

                <button class="remove-item"
                    onclick="removeItem(${item.id})">
                    Remove
                </button>
            </div>
        `;
    });

    document.getElementById("cart-total").textContent =
        total.toLocaleString();

    document.getElementById("cart-count").textContent = count;
}

// CHANGE PRODUCT QUANTITY
function changeQuantity(id, change) {
    const item = cart.find(p => p.id === id);

    if (!item) return;

    item.quantity += change;

    if (item.quantity <= 0) {
        removeItem(id);
        return;
    }

    updateCart();
}

// REMOVE ITEM
function removeItem(id) {
    cart = cart.filter(item => item.id !== id);
    updateCart();
}

// TOGGLE CART
function toggleCart() {
    document.getElementById("cart").classList.toggle("active");
}

// CHECKOUT THROUGH WHATSAPP
function checkout() {
    if (cart.length === 0) {
        alert("Your cart is empty!");
        return;
    }

    let message = "Hello GreenHarvest Agrovet! I would like to order:\n\n";
    let total = 0;

    cart.forEach(item => {
        message += `${item.name} - ${item.quantity} x KSh ${item.price.toLocaleString()}\n`;

        total += item.price * item.quantity;
    });

    message += `\nEstimated Total: KSh ${total.toLocaleString()}`;
    message += "\n\nPlease confirm product availability, final price and delivery.";

    const whatsappNumber = "254727625966";

    window.open(
        "https://wa.me/" + whatsappNumber +
        "?text=" + encodeURIComponent(message),
        "_blank"
    );
}

// CHECKOUT THROUGH WEBSITE
async function websiteCheckout() {
    if (cart.length === 0) {
        alert("Your cart is empty!");
        return;
    }

    // Verify customer login
    try {
        const response = await fetch("/api/auth/me");
        const data = await response.json();

        if (!data.user) {
            alert("Please log in before placing your order.");
            window.location.href = "login.html";
            return;
        }
    } catch (error) {
        alert("Unable to verify your account. Please try again.");
        return;
    }

    // Prevent duplicate checkout forms
    if (document.getElementById("checkout-form")) {
        return;
    }

    const cartPanel = document.getElementById("cart");
    const totalElement = document.querySelector(".cart-total");

    const form = document.createElement("form");
    form.id = "checkout-form";

    form.innerHTML = `
        <h3>Delivery Details</h3>

        <label for="checkout-phone">Phone Number</label>
        <input
            type="tel"
            id="checkout-phone"
            placeholder="e.g. 0712345678"
            required
        >

        <label for="checkout-address">Delivery Address</label>
        <textarea
            id="checkout-address"
            placeholder="Enter your delivery location"
            required
        ></textarea>

        <label for="checkout-notes">
            Additional Instructions (Optional)
        </label>

        <textarea
            id="checkout-notes"
            placeholder="Any special delivery instructions?"
        ></textarea>

        <label for="payment-method">Payment Method</label>

        <select id="payment-method" required>
            <option value="manual_mpesa">M-Pesa</option>
            <option value="cash_on_delivery">Cash on Delivery</option>
        </select>

        <button type="submit" id="place-order-btn">
            Place Order
        </button>

        <p id="checkout-message"></p>
    `;

    cartPanel.insertBefore(form, totalElement);

    form.addEventListener("submit", submitOrder);
}

// SUBMIT ORDER TO MYSQL
async function submitOrder(event) {
    event.preventDefault();

    if (cart.length === 0) {
        alert("Your cart is empty!");
        return;
    }

    const button = document.getElementById("place-order-btn");
    const message = document.getElementById("checkout-message");

    button.disabled = true;
    button.textContent = "Placing Order...";

    const orderData = {
        items: cart.map(item => ({
            productId: item.id,
            quantity: item.quantity
        })),

        phone: document.getElementById("checkout-phone").value.trim(),

        deliveryAddress: document
            .getElementById("checkout-address").value.trim(),

        deliveryNotes: document
            .getElementById("checkout-notes").value.trim(),

        paymentMethod: document.getElementById("payment-method").value
    };

    try {
        const response = await fetch("/api/orders", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(orderData)
        });

        const result = await response.json();

        if (!response.ok) {
            throw new Error(
                result.error || result.message || "Order could not be placed."
            );
        }

        alert(
            "Order placed successfully!\n\n" +
            "Order Number: " + result.orderNumber +
            "\nTotal: KSh " +
            Number(result.totalAmount).toLocaleString()
        );

        // Clear cart after successful order
        cart = [];
        updateCart();

        // Remove checkout form
        document.getElementById("checkout-form").remove();

        // Close cart
        document.getElementById("cart").classList.remove("active");

    } catch (error) {
        message.textContent = error.message;
        message.style.color = "red";

        button.disabled = false;
        button.textContent = "Place Order";
    }
}
