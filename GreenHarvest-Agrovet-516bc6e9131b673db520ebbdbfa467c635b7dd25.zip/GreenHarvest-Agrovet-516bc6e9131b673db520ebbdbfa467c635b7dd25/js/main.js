// MOBILE MENU

function toggleMenu() {
    document.getElementById("nav").classList.toggle("active");
}


// CONTACT FORM

function sendContact(event) {
    event.preventDefault();

    const name = document.getElementById("name").value;
    const email = document.getElementById("email").value;
    const phone = document.getElementById("phone").value;
    const message = document.getElementById("message").value;

    const whatsappNumber = "+254727625966";

    const text =
        `Hello GreenHarvest Agrovet!\n\n` +
        `Name: ${name}\nEmail: ${email}\n` +
        `Phone: ${phone}\nMessage: ${message}`;

    window.open(
        "https://wa.me/" + whatsappNumber +
        "?text=" + encodeURIComponent(text),
        "_blank"
    );
}


// INITIALIZE

displayProducts();
updateCart();
