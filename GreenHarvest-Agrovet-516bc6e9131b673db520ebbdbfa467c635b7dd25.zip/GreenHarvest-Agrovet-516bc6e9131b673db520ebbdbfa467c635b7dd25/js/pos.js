let posProducts = [];
let posCart = [];

document.addEventListener('DOMContentLoaded', async () => {
    document.getElementById('pos-search')
        .addEventListener('input', renderPOSProducts);

    document.getElementById('pos-discount')
        .addEventListener('input', updatePOSCart);

    document.getElementById('pos-payment-method')
        .addEventListener('change', togglePOSPaymentFields);

    document.getElementById('pos-complete-sale')
        .addEventListener('click', completePOSSale);

    document.getElementById('pos-history-search')
        .addEventListener('input', loadPOSSalesHistory);

    document.getElementById('pos-history-from')
        .addEventListener('change', loadPOSSalesHistory);

    document.getElementById('pos-history-to')
        .addEventListener('change', loadPOSSalesHistory);

    document.getElementById('pos-history-refresh')
        .addEventListener('click', loadPOSSalesHistory);

    document.getElementById('pos-history-clear')
        .addEventListener('click', clearPOSHistoryFilters);

    document.getElementById('pos-report-refresh')
        .addEventListener('click', loadPOSReports);
    document.getElementById('pos-report-export')
    .addEventListener('click', exportPOSReportCSV);

    await checkPOSAccess();
    togglePOSPaymentFields();
    updatePOSCart();
});

async function apiRequest(url, options = {}) {
    const response = await fetch(url, {
        credentials: 'same-origin',
        ...options,
        headers: {
            ...(options.body ? { 'Content-Type': 'application/json' } : {}),
            ...options.headers
        }
    });

    const data = await response.json();

    if (!response.ok) {
        throw new Error(data.error || data.message || 'Something went wrong.');
    }

    return data;
}

async function checkPOSAccess() {
    try {
        const data = await apiRequest('/api/auth/me');

        if (!data.user || data.user.role !== 'admin') {
            window.location.href = 'login.html';
            return;
        }

        await loadPOSProducts();
        await loadPOSSalesHistory();
        await loadPOSReports();

    } catch (error) {
        console.error('POS access error:', error);
        window.location.href = 'login.html';
    }
}

async function loadPOSProducts() {
    const container = document.getElementById('pos-products');

    try {
        const data = await apiRequest('/api/products');
        posProducts = data.products || [];
        renderPOSProducts();

    } catch (error) {
        container.textContent =
            'Unable to load products. Please refresh the page.';
        console.error(error);
    }
}

function renderPOSProducts() {
    const container = document.getElementById('pos-products');
    const search = document.getElementById('pos-search').value
        .trim().toLowerCase();

    container.replaceChildren();

    const filtered = posProducts.filter(product =>
        product.name.toLowerCase().includes(search) ||
        (product.category || '').toLowerCase().includes(search)
    );

    if (!filtered.length) {
        const message = document.createElement('p');
        message.className = 'pos-empty';
        message.textContent = 'No matching products found.';
        container.appendChild(message);
        return;
    }

    filtered.forEach(product => {
        const card = document.createElement('div');
        card.className = 'pos-product';

        const image = document.createElement('img');
        image.src = product.image_url || 'assets/placeholder.png';
        image.alt = product.name;

        const name = document.createElement('h3');
        name.textContent = product.name;

        const price = document.createElement('p');
        price.textContent = formatPOSMoney(product.price);

        const stock = document.createElement('small');
        stock.textContent = `Stock: ${product.stock_quantity}`;

        const button = document.createElement('button');
        button.textContent = Number(product.stock_quantity) > 0
            ? 'Add to Sale'
            : 'Out of Stock';

        button.disabled = Number(product.stock_quantity) <= 0;

        button.addEventListener('click', () =>
            addPOSProduct(product.id)
        );

        card.append(image, name, price, stock, button);
        container.appendChild(card);
    });
}

function addPOSProduct(productId) {
    const product = posProducts.find(item =>
        Number(item.id) === Number(productId)
    );

    if (!product || Number(product.stock_quantity) <= 0) {
        alert('This product is out of stock.');
        return;
    }

    const existing = posCart.find(item =>
        Number(item.id) === Number(productId)
    );

    if (existing) {
        if (existing.quantity >= Number(product.stock_quantity)) {
            alert('You cannot sell more than the available stock.');
            return;
        }

        existing.quantity++;

    } else {
        posCart.push({
            id: Number(product.id),
            name: product.name,
            price: Number(product.price),
            quantity: 1,
            stock: Number(product.stock_quantity)
        });
    }

    updatePOSCart();
}

function changePOSQuantity(productId, change) {
    const item = posCart.find(product =>
        Number(product.id) === Number(productId)
    );

    if (!item) return;

    const newQuantity = item.quantity + change;

    if (newQuantity <= 0) {
        removePOSProduct(productId);
        return;
    }

    if (newQuantity > item.stock) {
        alert('You cannot exceed the available stock.');
        return;
    }

    item.quantity = newQuantity;
    updatePOSCart();
}

function removePOSProduct(productId) {
    posCart = posCart.filter(item =>
        Number(item.id) !== Number(productId)
    );

    updatePOSCart();
}

function updatePOSCart() {
    const container = document.getElementById('pos-cart');
    container.replaceChildren();

    if (!posCart.length) {
        const empty = document.createElement('p');
        empty.className = 'pos-empty';
        empty.textContent = 'No products added yet.';
        container.appendChild(empty);

    } else {
        const table = document.createElement('table');
        table.className = 'pos-cart-table';

        const header = document.createElement('tr');

        ['Product', 'Price', 'Qty', 'Total', ''].forEach(label => {
            const th = document.createElement('th');
            th.textContent = label;
            header.appendChild(th);
        });

        const thead = document.createElement('thead');
        thead.appendChild(header);
        table.appendChild(thead);

        const tbody = document.createElement('tbody');

        posCart.forEach(item => {
            const row = document.createElement('tr');

            const name = document.createElement('td');
            name.textContent = item.name;

            const price = document.createElement('td');
            price.textContent = formatPOSMoney(item.price);

            const quantity = document.createElement('td');
            quantity.className = 'pos-quantity';

            const minus = document.createElement('button');
            minus.textContent = '−';
            minus.addEventListener('click', () =>
                changePOSQuantity(item.id, -1)
            );

            const count = document.createElement('span');
            count.textContent = ` ${item.quantity} `;

            const plus = document.createElement('button');
            plus.textContent = '+';
            plus.addEventListener('click', () =>
                changePOSQuantity(item.id, 1)
            );

            quantity.append(minus, count, plus);

            const total = document.createElement('td');
            total.textContent =
                formatPOSMoney(item.price * item.quantity);

            const removeCell = document.createElement('td');

            const remove = document.createElement('button');
            remove.textContent = '×';
            remove.title = 'Remove product';

            remove.addEventListener('click', () =>
                removePOSProduct(item.id)
            );

            removeCell.appendChild(remove);

            row.append(name, price, quantity, total, removeCell);
            tbody.appendChild(row);
        });

        table.appendChild(tbody);
        container.appendChild(table);
    }

    const subtotal = posCart.reduce(
        (sum, item) => sum + item.price * item.quantity, 0
    );

    const requestedDiscount = Math.max(
        0,
        Number(document.getElementById('pos-discount').value) || 0
    );

    const discount = Math.min(requestedDiscount, subtotal);
    const total = subtotal - discount;

    document.getElementById('pos-subtotal').textContent =
        formatPOSMoney(subtotal);

    document.getElementById('pos-discount-display').textContent =
        formatPOSMoney(discount);

    document.getElementById('pos-total').textContent =
        formatPOSMoney(total);
}

function formatPOSMoney(amount) {
    return 'KSh ' + Number(amount).toLocaleString('en-KE', {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    });
}

function togglePOSPaymentFields() {
    const method =
        document.getElementById('pos-payment-method').value;

    document.getElementById('pos-reference-field').hidden =
        !['mpesa', 'bank_transfer'].includes(method);
}

// Display receipt after a successful sale
function showPOSReceipt(receipt) {
    let receiptSection = document.getElementById('pos-receipt');

    if (!receiptSection) {
        receiptSection = document.createElement('section');
        receiptSection.id = 'pos-receipt';

        const cartSection = document.getElementById('pos-cart')
            .closest('section, .pos-cart-section, .pos-panel');

        const parent = cartSection || document.getElementById('pos-cart')
            .parentElement;

        parent.appendChild(receiptSection);
    }

    receiptSection.replaceChildren();

    const heading = document.createElement('h2');
    heading.textContent = 'Sale Receipt';

    const message = document.createElement('p');
    message.textContent =
        'Sale completed successfully. Your receipt is ready.';

    const printButton = document.createElement('button');
    printButton.type = 'button';
    printButton.textContent = 'Print Receipt';
    printButton.addEventListener('click', () =>
        printPOSReceipt(receipt)
    );

    const receiptInfo = document.createElement('div');
    receiptInfo.innerHTML = `
        <p><strong>Receipt:</strong> ${escapeReceiptHTML(receipt.orderNumber)}</p>
        <p><strong>Customer:</strong> ${escapeReceiptHTML(receipt.customer.name)}</p>
        <p><strong>Total:</strong> ${formatPOSMoney(receipt.totalAmount)}</p>
    `;

    receiptSection.append(
        heading,
        message,
        receiptInfo,
        printButton
    );
}

function escapeReceiptHTML(value) {
    return String(value ?? '').replace(/[&<>"']/g, character => ({
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#39;'
    })[character]);
}

// Open a clean printable receipt
function printPOSReceipt(receipt) {
    const printWindow = window.open('', '_blank', 'width=420,height=700');

    if (!printWindow) {
        alert('Please allow pop-ups to print the receipt.');
        return;
    }

    const itemsHTML = (receipt.items || []).map(item => `
        <tr>
            <td>${escapeReceiptHTML(item.name)}</td>
            <td>${Number(item.quantity)}</td>
            <td>${formatPOSMoney(item.unitPrice)}</td>
            <td>${formatPOSMoney(item.lineTotal)}</td>
        </tr>
    `).join('');

    const date = new Date(receipt.date);
    const formattedDate = Number.isNaN(date.getTime())
        ? '—'
        : date.toLocaleString('en-KE', {
            timeZone: 'Africa/Nairobi'
        });

    printWindow.document.write(`
        <!DOCTYPE html>
        <html>
        <head>
            <title>Receipt ${escapeReceiptHTML(receipt.orderNumber)}</title>
            <style>
                body {
                    font-family: Arial, sans-serif;
                    width: 320px;
                    margin: 15px auto;
                    color: #111;
                    font-size: 12px;
                }
                h2, p.center { text-align: center; }
                h2 { margin-bottom: 4px; }
                .line {
                    border-top: 1px dashed #333;
                    margin: 10px 0;
                }
                table {
                    width: 100%;
                    border-collapse: collapse;
                    font-size: 11px;
                }
                th, td {
                    padding: 5px 2px;
                    text-align: left;
                    border-bottom: 1px dotted #ccc;
                }
                .totals p {
                    display: flex;
                    justify-content: space-between;
                    margin: 6px 0;
                }
                .grand-total {
                    font-size: 16px;
                    font-weight: bold;
                }
                .footer {
                    text-align: center;
                    margin-top: 18px;
                }
                @media print {
                    body { margin: 0 auto; }
                }
            </style>
        </head>
        <body>
            <h2>${escapeReceiptHTML(receipt.businessName || 'GreenHarvest Agrovet')}</h2>
            <p class="center">SALES RECEIPT</p>
            <div class="line"></div>

            <p><strong>Receipt No:</strong> ${escapeReceiptHTML(receipt.orderNumber)}</p>
            <p><strong>Date:</strong> ${escapeReceiptHTML(formattedDate)}</p>
            <p><strong>Customer:</strong> ${escapeReceiptHTML(receipt.customer?.name || 'Walk-in Customer')}</p>
            <p><strong>Phone:</strong> ${escapeReceiptHTML(receipt.customer?.phone || 'N/A')}</p>

            <div class="line"></div>

            <table>
                <thead>
                    <tr>
                        <th>Item</th>
                        <th>Qty</th>
                        <th>Price</th>
                        <th>Total</th>
                    </tr>
                </thead>
                <tbody>${itemsHTML}</tbody>
            </table>

            <div class="line"></div>

            <div class="totals">
                <p><span>Subtotal</span><strong>${formatPOSMoney(receipt.subtotal)}</strong></p>
                <p><span>Discount</span><strong>${formatPOSMoney(receipt.discount)}</strong></p>
                <p class="grand-total"><span>Total</span><strong>${formatPOSMoney(receipt.totalAmount)}</strong></p>
            </div>

            <div class="line"></div>

            <p><strong>Payment:</strong> ${escapeReceiptHTML(String(receipt.payment?.method || 'N/A').replaceAll('_', ' ').toUpperCase())}</p>
            <p><strong>Reference:</strong> ${escapeReceiptHTML(receipt.payment?.reference || 'N/A')}</p>
            <p><strong>Status:</strong> ${escapeReceiptHTML(receipt.payment?.status || 'Paid')}</p>

            <div class="line"></div>
            <p class="footer">Thank you for shopping with us!</p>

            <script>
                window.onload = function () {
                    window.print();
                };
            <\/script>
        </body>
        </html>
    `);

    printWindow.document.close();
}
async function completePOSSale() {
    const button = document.getElementById('pos-complete-sale');
    const message = document.getElementById('pos-message');

    if (!posCart.length) {
        message.textContent = 'Please add products to the sale.';
        return;
    }

    const paymentMethod =
        document.getElementById('pos-payment-method').value;

    const paymentReference =
        document.getElementById('pos-payment-reference').value.trim();

    const paymentConfirmed =
        document.getElementById('pos-payment-confirmed').checked;

    if (!paymentConfirmed) {
        message.textContent =
            'Please confirm that payment has been received.';
        return;
    }

    if (
        ['mpesa', 'bank_transfer'].includes(paymentMethod) &&
        !paymentReference
    ) {
        message.textContent =
            'Please enter the payment transaction reference.';
        return;
    }

    const discount =
        Number(document.getElementById('pos-discount').value) || 0;

    const payload = {
        items: posCart.map(item => ({
            productId: item.id,
            quantity: item.quantity
        })),

        customerName:
            document.getElementById('pos-customer-name').value.trim(),

        customerPhone:
            document.getElementById('pos-customer-phone').value.trim(),

        discount,
        paymentMethod,
        paymentReference,
        paymentConfirmed
    };

    try {
        button.disabled = true;
        button.textContent = 'Processing sale...';
        message.textContent = '';

        const result = await apiRequest('/api/admin/pos-sales', {
            method: 'POST',
            body: JSON.stringify(payload)
        });

        if (!result.receipt) {
            throw new Error(
                'Sale was recorded, but receipt information was not returned. Check the server response.'
            );
        }

        // Show the receipt before clearing the sale information.
        showPOSReceipt(result.receipt);

        posCart = [];

        document.getElementById('pos-discount').value = 0;
        document.getElementById('pos-customer-name').value = '';
        document.getElementById('pos-customer-phone').value = '';
        document.getElementById('pos-payment-reference').value = '';
        document.getElementById('pos-payment-confirmed').checked = false;

        await loadPOSProducts();
        updatePOSCart();
        await loadPOSSalesHistory();

        message.textContent =
            `Sale recorded successfully. Receipt: ${result.receipt.orderNumber}`;

    } catch (error) {
        message.textContent = error.message;
        console.error('POS sale error:', error);

    } finally {
        button.disabled = false;
        button.textContent = 'Complete Sale';
    }
}

// ---------------- POS SALES HISTORY ----------------

async function loadPOSSalesHistory() {
    const container = document.getElementById('pos-history-list');
    const message = document.getElementById('pos-history-message');
    if (!container || !message) return;

    const search = document.getElementById('pos-history-search').value.trim();
    const from = document.getElementById('pos-history-from').value;
    const to = document.getElementById('pos-history-to').value;

    const params = new URLSearchParams();
    if (search) params.set('search', search);
    if (from) params.set('from', from);
    if (to) params.set('to', to);

    container.replaceChildren();
    message.textContent = 'Loading sales history...';

    try {
        const data = await apiRequest(
            `/api/admin/pos-sales${params.toString() ? `?${params}` : ''}`
        );

        renderPOSSalesHistory(data.sales || []);
        message.textContent = `${(data.sales || []).length} sale(s) found. Showing up to 300 records.`;
    } catch (error) {
        message.textContent = error.message;
        console.error('POS sales history error:', error);
    }
}

function renderPOSSalesHistory(sales) {
    const container = document.getElementById('pos-history-list');
    container.replaceChildren();

    if (!sales.length) {
        const empty = document.createElement('p');
        empty.className = 'pos-empty';
        empty.textContent = 'No POS sales found for the selected filters.';
        container.appendChild(empty);
        return;
    }

    const table = document.createElement('table');
    table.className = 'pos-cart-table';

    const thead = document.createElement('thead');
    const header = document.createElement('tr');

    ['Receipt No.', 'Date', 'Customer', 'Items', 'Total', 'Payment', 'Actions']
        .forEach(label => {
            const th = document.createElement('th');
            th.textContent = label;
            header.appendChild(th);
        });

    thead.appendChild(header);
    table.appendChild(thead);

    const tbody = document.createElement('tbody');

    sales.forEach(sale => {
        const row = document.createElement('tr');
        const date = new Date(sale.created_at);

        const values = [
            sale.order_number,
            Number.isNaN(date.getTime())
                ? '—'
                : date.toLocaleString('en-KE', {
                    timeZone: 'Africa/Nairobi'
                }),
            sale.customer_name,
            sale.total_items,
            formatPOSMoney(sale.total_amount),
            String(sale.payment_method || '')
                .replaceAll('_', ' ')
                .toUpperCase()
        ];

        values.forEach(value => {
            const cell = document.createElement('td');
            cell.textContent = value ?? '—';
            row.appendChild(cell);
        });

        const actions = document.createElement('td');
        const viewButton = document.createElement('button');

        viewButton.type = 'button';
        viewButton.textContent = 'View / Reprint';
        viewButton.addEventListener('click', () => viewPOSSale(sale.id));

        actions.appendChild(viewButton);
        row.appendChild(actions);
        tbody.appendChild(row);
    });

    table.appendChild(tbody);
    container.appendChild(table);
}

function clearPOSHistoryFilters() {
    document.getElementById('pos-history-search').value = '';
    document.getElementById('pos-history-from').value = '';
    document.getElementById('pos-history-to').value = '';

    loadPOSSalesHistory();
}

async function viewPOSSale(saleId) {
    const details = document.getElementById('pos-history-details');

    details.hidden = false;
    details.replaceChildren();

    const loading = document.createElement('p');
    loading.textContent = 'Loading sale details...';
    details.appendChild(loading);

    try {
        const data = await apiRequest(
            `/api/admin/pos-sales/${encodeURIComponent(saleId)}`
        );

        const sale = data.sale;
        const payment = (data.payments || [])[0] || {};

        const receipt = {
            orderNumber: sale.order_number,
            date: sale.created_at,
            businessName: 'GreenHarvest Agrovet',

            customer: {
                name: sale.customer_name || 'Walk-in Customer',
                phone: sale.customer_phone || 'N/A'
            },

            items: (data.items || []).map(item => ({
                name: item.product_name,
                quantity: Number(item.quantity),
                unitPrice: Number(item.unit_price),
                lineTotal: Number(item.line_total)
            })),

            subtotal: Number(sale.subtotal),
            discount: Number(sale.discount_amount || 0),
            totalAmount: Number(sale.total_amount),

            payment: {
                method: payment.provider || sale.payment_method || 'N/A',
                reference: payment.transaction_reference || 'N/A',
                status: payment.status === 'successful'
                    ? 'Paid'
                    : (
                        payment.status ||
                        sale.payment_status ||
                        'N/A'
                    )
            }
        };

        details.replaceChildren();

        const heading = document.createElement('h3');
        heading.textContent = `Sale details — ${receipt.orderNumber}`;

        const summary = document.createElement('p');
        summary.textContent =
            `Customer: ${receipt.customer.name} | ` +
            `Phone: ${receipt.customer.phone} | ` +
            `Total: ${formatPOSMoney(receipt.totalAmount)}`;

        const printButton = document.createElement('button');
        printButton.type = 'button';
        printButton.textContent = 'Reprint Receipt';
        printButton.addEventListener('click', () =>
            printPOSReceipt(receipt)
        );

        const closeButton = document.createElement('button');
        closeButton.type = 'button';
        closeButton.textContent = 'Close Details';

        closeButton.addEventListener('click', () => {
            details.hidden = true;
            details.replaceChildren();
        });

        const itemsTable = document.createElement('table');
        itemsTable.className = 'pos-cart-table';

        const head = document.createElement('thead');
        const headRow = document.createElement('tr');

        ['Product', 'Quantity', 'Unit Price', 'Line Total']
            .forEach(label => {
                const th = document.createElement('th');
                th.textContent = label;
                headRow.appendChild(th);
            });

        head.appendChild(headRow);
        itemsTable.appendChild(head);

        const body = document.createElement('tbody');

        receipt.items.forEach(item => {
            const row = document.createElement('tr');

            [
                item.name,
                item.quantity,
                formatPOSMoney(item.unitPrice),
                formatPOSMoney(item.lineTotal)
            ].forEach(value => {
                const cell = document.createElement('td');
                cell.textContent = value;
                row.appendChild(cell);
            });

            body.appendChild(row);
        });

        itemsTable.appendChild(body);

        const totals = document.createElement('p');
        totals.textContent =
            `Subtotal: ${formatPOSMoney(receipt.subtotal)} | ` +
            `Discount: ${formatPOSMoney(receipt.discount)} | ` +
            `Total: ${formatPOSMoney(receipt.totalAmount)}`;

        details.append(
            heading,
            summary,
            itemsTable,
            totals,
            printButton,
            closeButton
        );

        details.scrollIntoView({
            behavior: 'smooth',
            block: 'center'
        });

    } catch (error) {
        details.replaceChildren();

        const errorMessage = document.createElement('p');
        errorMessage.textContent = error.message;
        details.appendChild(errorMessage);

        console.error('Unable to load POS sale:', error);
    }
}

async function adminLogout() {
    try {
        await apiRequest('/api/auth/logout', {
            method: 'POST'
        });

        window.location.href = 'login.html';

    } catch (error) {
        alert(error.message);
    }
}

// ---------------- POS SALES REPORTS ----------------

async function loadPOSReports() {
    const message = document.getElementById('pos-report-message');
    const paymentsContainer = document.getElementById('pos-report-payments');

    const from = document.getElementById('pos-report-from').value;
    const to = document.getElementById('pos-report-to').value;

    const params = new URLSearchParams();

    if (from) params.set('from', from);
    if (to) params.set('to', to);

    message.textContent = 'Loading sales report...';

    try {
        const data = await apiRequest(
            `/api/admin/pos-reports${params.toString() ? `?${params}` : ''}`
        );

        const report = data.report;

        document.getElementById('report-total-sales').textContent =
            formatPOSMoney(report.totalSales);

        document.getElementById('report-total-transactions').textContent =
            Number(report.totalTransactions).toLocaleString('en-KE');

        document.getElementById('report-total-discounts').textContent =
            formatPOSMoney(report.totalDiscounts);

        renderPOSPaymentReport(data.paymentMethods || []);

        message.textContent =
            `Report generated successfully. ${report.totalTransactions} transaction(s) found.`;

    } catch (error) {
        message.textContent = error.message;
        paymentsContainer.textContent = 'Unable to load payment breakdown.';

        console.error('POS reports error:', error);
    }
}


function renderPOSPaymentReport(paymentMethods) {
    const container = document.getElementById('pos-report-payments');

    container.replaceChildren();

    if (!paymentMethods.length) {
        const empty = document.createElement('p');
        empty.className = 'pos-empty';
        empty.textContent = 'No payment records found for this period.';
        container.appendChild(empty);
        return;
    }

    const table = document.createElement('table');
    table.className = 'pos-cart-table';

    const thead = document.createElement('thead');
    const header = document.createElement('tr');

    ['Payment Method', 'Transactions', 'Total Sales'].forEach(label => {
        const th = document.createElement('th');
        th.textContent = label;
        header.appendChild(th);
    });

    thead.appendChild(header);
    table.appendChild(thead);

    const tbody = document.createElement('tbody');

    paymentMethods.forEach(item => {
        const row = document.createElement('tr');

        const method = String(item.paymentMethod || '')
            .replaceAll('_', ' ')
            .toUpperCase();

        [
            method,
            Number(item.transactions),
            formatPOSMoney(item.totalSales)
        ].forEach(value => {
            const cell = document.createElement('td');
            cell.textContent = value;
            row.appendChild(cell);
        });

        tbody.appendChild(row);
    });

    table.appendChild(tbody);
    container.appendChild(table);
}

// ---------------- EXPORT POS REPORT TO CSV ----------------

async function exportPOSReportCSV() {
    const button = document.getElementById('pos-report-export');
    const message = document.getElementById('pos-report-message');

    const from = document.getElementById('pos-report-from').value;
    const to = document.getElementById('pos-report-to').value;

    if (from && to && from > to) {
        message.textContent = 'The start date cannot be after the end date.';
        return;
    }

    const params = new URLSearchParams();

    if (from) params.set('from', from);
    if (to) params.set('to', to);

    button.disabled = true;
    button.textContent = 'Preparing CSV...';
    message.textContent = 'Preparing your sales report for download...';

    try {
        // Retrieve the summary and payment breakdown
        const reportData = await apiRequest(
            `/api/admin/pos-reports${params.toString() ? `?${params}` : ''}`
        );

        // Retrieve individual sales for the same date range
        const salesData = await apiRequest(
            `/api/admin/pos-sales${params.toString() ? `?${params}` : ''}`
        );

        const report = reportData.report;
        const sales = salesData.sales || [];
        const paymentMethods = reportData.paymentMethods || [];

        const rows = [];

        // Report heading
        rows.push(['GREENHARVEST AGROVET - POS SALES REPORT']);
        rows.push(['From Date', from || 'Today']);
        rows.push(['To Date', to || 'Today']);
        rows.push([]);

        // Summary
        rows.push(['SALES SUMMARY']);
        rows.push(['Total Transactions', report.totalTransactions]);
        rows.push(['Total Sales (KSh)', report.totalSales]);
        rows.push(['Total Discounts (KSh)', report.totalDiscounts]);
        rows.push([]);

        // Payment breakdown
        rows.push(['SALES BY PAYMENT METHOD']);
        rows.push(['Payment Method', 'Transactions', 'Total Sales (KSh)']);

        paymentMethods.forEach(item => {
            rows.push([
                item.paymentMethod,
                item.transactions,
                item.totalSales
            ]);
        });

        rows.push([]);

        // Individual transactions
        rows.push(['INDIVIDUAL POS TRANSACTIONS']);
        rows.push([
            'Receipt Number',
            'Date',
            'Customer Name',
            'Customer Phone',
            'Payment Method',
            'Total Amount (KSh)'
        ]);

        sales.forEach(sale => {
            rows.push([
                sale.order_number,
                sale.created_at,
                sale.customer_name,
                sale.customer_phone,
                sale.payment_method,
                sale.total_amount
            ]);
        });

        // Escape CSV values safely
        const csvContent = rows.map(row =>
            row.map(value => {
                const text = String(value ?? '');
                return `"${text.replace(/"/g, '""')}"`;
            }).join(',')
        ).join('\r\n');

        // Add UTF-8 BOM for Excel compatibility
        const blob = new Blob(
            ['\uFEFF' + csvContent],
            { type: 'text/csv;charset=utf-8;' }
        );

        const downloadUrl = URL.createObjectURL(blob);
        const link = document.createElement('a');

        const dateLabel = new Date().toISOString().slice(0, 10);

        link.href = downloadUrl;
        link.download = `GreenHarvest-POS-Report-${dateLabel}.csv`;

        document.body.appendChild(link);
        link.click();
        link.remove();

        URL.revokeObjectURL(downloadUrl);

        message.textContent =
            `CSV report downloaded successfully. ${sales.length} transaction(s) exported.`;

    } catch (error) {
        message.textContent = error.message;
        console.error('POS CSV export error:', error);

    } finally {
        button.disabled = false;
        button.textContent = 'Export CSV';
    }
}
