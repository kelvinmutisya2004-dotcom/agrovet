
// PRODUCTS FROM MYSQL DATABASE

let products = [];
let cart = [];

// LOAD PRODUCTS FROM THE BACKEND
async function loadProducts() {
    const list = document.getElementById("product-list");

    try {
        list.innerHTML = "<p>Loading products...</p>";

        const response = await fetch("/api/products");

        if (!response.ok) {
            throw new Error("Unable to load products.");
        }

        const data = await response.json();

        // Support either an array or an object containing products
        const databaseProducts = Array.isArray(data)
            ? data
            : data.products;

        if (!Array.isArray(databaseProducts)) {
            throw new Error("Unexpected product data received.");
        }

        products = databaseProducts.map(product => ({
            id: Number(product.id),
            name: product.name,
            category: product.category_slug || product.category,
            price: Number(product.price),
            image: product.image_url || product.image
        }));

        displayProducts();

    } catch (error) {
        console.error("Product loading error:", error);
        list.innerHTML = "<p>Unable to load products. Please try again.</p>";
    }
}

// DISPLAY PRODUCTS
function displayProducts() {
    const list = document.getElementById("product-list");
    const search = document.getElementById("search").value.toLowerCase();
    const filter = document.getElementById("filter").value;

    const filtered = products.filter(product => {
        return product.name.toLowerCase().includes(search) &&
            (filter === "all" || product.category === filter);
    });

    list.innerHTML = "";

    if (filtered.length === 0) {
        list.innerHTML = "<p>No products found.</p>";
        return;
    }

    filtered.forEach(product => {
        list.innerHTML += `
            <div class="product">
                <img src="${product.image || ''}" alt="${product.name}">
                <div class="product-info">
                    <h3>${product.name}</h3>
                    <p>Category: ${product.category || 'General'}</p>
                    <div class="price">
                        KSh ${product.price.toLocaleString()}
                    </div>
                    <button class="add-btn"
                        onclick="addToCart(${product.id})">
                        Add to Cart
                    </button>
                </div>
            </div>
        `;
    });
}

// LOAD PRODUCTS WHEN THE PAGE IS READY
loadProducts();
