# GreenHarvest backend (Milestone 1)

This backend uses Node.js built-in `http` (no Express or other web framework) and MySQL. `mysql2` is the database driver; `dotenv` loads local settings.

## Included in this milestone

- MySQL schema for users, sessions, categories, products, orders, order items, payments and business settings.
- Public product/category API.
- Customer registration, login, logout and current-session API.
- Admin-only product create/update/deactivate API.
- Authenticated order creation with server-side price and stock checks.
- Customer order history and admin order list/status API.
- First-admin creation script.

## Setup

1. Install Node.js LTS and MySQL Server on your computer.
2. Open MySQL Workbench or the MySQL command line and run `database/greenharvest.sql`.
3. Open a terminal in this `server` folder and run `npm install`.
4. Copy `.env.example` to `.env` and edit `DB_USER` and `DB_PASSWORD` to match your MySQL account. Leave the business settings in MySQL blank until you receive the details.
5. Run `npm run create-admin` once to create the administrator account.
6. Run `npm start` and open `http://localhost:3000`.
7. Test `http://localhost:3000/api/health`; it should return `{"status":"ok","database":"connected"}`.

## Important

This is a local development milestone, not a production deployment. Before public launch we must add HTTPS, CSRF protection, login rate limiting, stronger request validation, backups, secure hosting configuration and a properly configured M-Pesa integration. Do not use real customer data until those steps are complete.
