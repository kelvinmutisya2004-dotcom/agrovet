require('dotenv').config();
const readline = require('node:readline/promises');
const { stdin: input, stdout: output } = require('node:process');
const { scryptSync, randomBytes } = require('node:crypto');
const db = require('./config/database');

(async () => {
  const rl = readline.createInterface({ input, output });
  try {
    const [admins] = await db.query("SELECT COUNT(*) AS total FROM users WHERE role = 'admin'");
    if (admins[0].total > 0) {
      console.log('An administrator already exists. Use the admin account to manage access.');
      return;
    }
    const fullName = (await rl.question('Administrator full name: ')).trim();
    const email = (await rl.question('Administrator email: ')).trim().toLowerCase();
    const phone = (await rl.question('Phone (optional, press Enter to skip): ')).trim();
    const password = await rl.question('Create a strong password (minimum 10 characters): ');
    if (!fullName || !email || password.length < 10) {
      throw new Error('Name and email are required; password must be at least 10 characters.');
    }
    const salt = randomBytes(16).toString('hex');
    const hash = scryptSync(password, salt, 64).toString('hex');
    await db.query(
      "INSERT INTO users (full_name,email,phone,password_hash,role) VALUES (?,?,?,?, 'admin')",
      [fullName, email, phone || null, `${salt}:${hash}`]
    );
    console.log('Administrator account created successfully. Keep these login details private.');
  } catch (error) {
    console.error('Could not create administrator:', error.message);
    process.exitCode = 1;
  } finally {
    rl.close();
    await db.end();
  }
})();
