
require('dotenv').config();

const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const {
  randomBytes,
  createHash,
  scryptSync,
  timingSafeEqual
} = require('node:crypto');

const db = require('./config/database');
const { OAuth2Client } = require('google-auth-library');

const googleClient = new OAuth2Client(process.env.GOOGLE_CLIENT_ID);

const ROOT = path.resolve(__dirname, '..');
const PORT = Number(process.env.PORT || 3000);
const SESSION_DAYS = 7;

const UPLOAD_DIR = path.join(ROOT, 'assets', 'uploads', 'products');
const MAX_IMAGE_SIZE = 3 * 1024 * 1024;

fs.mkdirSync(UPLOAD_DIR, { recursive: true });

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.webp': 'image/webp',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon'
};

function send(res, status, data, headers = {}) {
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
    ...headers
  });

  res.end(JSON.stringify(data));
}

function parseCookies(header = '') {
  return Object.fromEntries(
    header.split(';')
      .map(v => v.trim())
      .filter(Boolean)
      .map(v => {
        const i = v.indexOf('=');
        return [
          v.slice(0, i),
          decodeURIComponent(v.slice(i + 1))
        ];
      })
  );
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let raw = '';

    req.on('data', chunk => {
      raw += chunk;

      if (raw.length > 1000000) {
        reject(new Error('Request body is too large.'));
        req.destroy();
      }
    });

    req.on('end', () => {
      try {
        resolve(raw ? JSON.parse(raw) : {});
      } catch {
        reject(new Error('Request body must be valid JSON.'));
      }
    });

    req.on('error', reject);
  });
}

// Read image upload requests
function readImageBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let total = 0;

    req.on('data', chunk => {
      total += chunk.length;

      if (total > 5 * 1024 * 1024) {
        reject(new Error('Upload request is too large.'));
        req.destroy();
        return;
      }

      chunks.push(chunk);
    });

    req.on('end', () => {
      try {
        resolve(JSON.parse(Buffer.concat(chunks).toString('utf8')));
      } catch {
        reject(new Error('Invalid image upload request.'));
      }
    });

    req.on('error', reject);
  });
}

function hashToken(token) {
  return createHash('sha256').update(token).digest('hex');
}

function hashPassword(password, salt = randomBytes(16).toString('hex')) {
  return `${salt}:${scryptSync(password, salt, 64).toString('hex')}`;
}

function verifyPassword(password, stored) {
  const [salt, original] = String(stored).split(':');

  if (!salt || !original) return false;

  const candidate = Buffer.from(
    scryptSync(password, salt, 64).toString('hex'),
    'hex'
  );

  const expected = Buffer.from(original, 'hex');

  return candidate.length === expected.length &&
    timingSafeEqual(candidate, expected);
}

async function getUser(req) {
  const token = parseCookies(req.headers.cookie).gh_session;

  if (!token) return null;

  const [rows] = await db.query(
    `SELECT u.id,u.full_name,u.email,u.phone,u.role
     FROM sessions s
     JOIN users u ON u.id=s.user_id
     WHERE s.token_hash=?
     AND s.expires_at > NOW()
     AND u.is_active=1
     LIMIT 1`,
    [hashToken(token)]
  );

  return rows[0] || null;
}

function requireUser(user, res) {
  if (!user) {
    send(res, 401, {
      error: 'Please log in to continue.'
    });

    return false;
  }

  return true;
}

function requireAdmin(user, res) {
  if (!user || user.role !== 'admin') {
    send(res, 403, {
      error: 'Administrator access is required.'
    });

    return false;
  }

  return true;
}

async function createSession(userId, res) {
  const token = randomBytes(32).toString('hex');

  const expires = new Date(
    Date.now() + SESSION_DAYS * 86400000
  );

  await db.query(
    'INSERT INTO sessions (user_id,token_hash,expires_at) VALUES (?,?,?)',
    [userId, hashToken(token), expires]
  );

  const secure = process.env.NODE_ENV === 'production'
    ? '; Secure'
    : '';

  res.setHeader(
    'Set-Cookie',
    `gh_session=${encodeURIComponent(token)}; HttpOnly; SameSite=Lax; Path=/; Max-Age=${SESSION_DAYS * 86400}${secure}`
  );
}

async function api(req, res, url) {
  const method = req.method;
  const pathname = url.pathname;

  const user = await getUser(req);

  // Health check
  if (method === 'GET' && pathname === '/api/health') {
    await db.query('SELECT 1');

    return send(res, 200, {
      status: 'ok',
      database: 'connected'
    });
  }

  // Get products
  if (method === 'GET' && pathname === '/api/products') {
    const search = (url.searchParams.get('search') || '').trim();
    const category = (url.searchParams.get('category') || '').trim();

    const [rows] = await db.query(
      `SELECT p.id,p.name,p.description,p.price,
       p.stock_quantity,p.low_stock_threshold,p.image_url,
       c.name AS category,c.slug AS category_slug
       FROM products p
       JOIN categories c ON c.id=p.category_id
       WHERE p.is_active=1
       AND c.is_active=1
       AND p.name LIKE ?
       AND (?='' OR c.slug=?)
       ORDER BY p.created_at DESC`,
      [`%${search}%`, category, category]
    );

    return send(res, 200, {
      products: rows
    });
  }

  // Get categories
  if (method === 'GET' && pathname === '/api/categories') {
    const [rows] = await db.query(
      'SELECT id,name,slug FROM categories WHERE is_active=1 ORDER BY name'
    );

    return send(res, 200, {
      categories: rows
    });
  }

  // Upload product image
  if (
    method === 'POST' &&
    pathname === '/api/admin/upload-product-image'
  ) {
    if (!requireAdmin(user, res)) return;

    const body = await readImageBody(req);
    const imageData = String(body.image || '');

    const match = imageData.match(
      /^data:(image\/(?:jpeg|png|webp));base64,([A-Za-z0-9+/]*={0,2})$/
    );

    if (!match) {
      return send(res, 400, {
        error: 'Please upload a valid JPG, PNG or WEBP image.'
      });
    }

    const mimeType = match[1];
    const buffer = Buffer.from(match[2], 'base64');

    if (!buffer.length || buffer.length > MAX_IMAGE_SIZE) {
      return send(res, 400, {
        error: 'Image must be smaller than 3 MB.'
      });
    }

    // Verify actual image file signatures
    const isPNG =
      buffer.length >= 8 &&
      buffer.subarray(0, 8).equals(
        Buffer.from([137, 80, 78, 71, 13, 10, 26, 10])
      );

    const isJPEG =
      buffer.length >= 3 &&
      buffer[0] === 0xFF &&
      buffer[1] === 0xD8 &&
      buffer[2] === 0xFF;

    const isWEBP =
      buffer.length >= 12 &&
      buffer.toString('ascii', 0, 4) === 'RIFF' &&
      buffer.toString('ascii', 8, 12) === 'WEBP';

    if (
      (mimeType === 'image/png' && !isPNG) ||
      (mimeType === 'image/jpeg' && !isJPEG) ||
      (mimeType === 'image/webp' && !isWEBP)
    ) {
      return send(res, 400, {
        error: 'The image file does not match its format.'
      });
    }

    const extension = {
      'image/jpeg': '.jpg',
      'image/png': '.png',
      'image/webp': '.webp'
    }[mimeType];

    const filename = randomBytes(16).toString('hex') + extension;
    const destination = path.join(UPLOAD_DIR, filename);

    await fs.promises.writeFile(
      destination,
      buffer,
      { flag: 'wx' }
    );

    // Correct image upload response
    return send(res, 201, {
      message: 'Product image uploaded successfully.',
      imageUrl: `/assets/uploads/products/${filename}`
    });
  }

  // Register customer
  if (method === 'POST' && pathname === '/api/auth/register') {
    const body = await readBody(req);

    const name = String(body.fullName || '').trim();
    const email = String(body.email || '').trim().toLowerCase();
    const phone = String(body.phone || '').trim();
    const password = String(body.password || '');

    if (
      name.length < 2 ||
      !/^\S+@\S+\.\S+$/.test(email) ||
      password.length < 8
    ) {
      return send(res, 400, {
        error: 'Enter your name, a valid email and a password of at least 8 characters.'
      });
    }

    try {
      const [result] = await db.query(
        "INSERT INTO users (full_name,email,phone,password_hash,role) VALUES (?,?,?,?, 'customer')",
        [name, email, phone || null, hashPassword(password)]
      );

      await createSession(result.insertId, res);

      return send(res, 201, {
        message: 'Account created.',
        user: {
          id: result.insertId,
          full_name: name,
          email,
          phone,
          role: 'customer'
        }
      });

    } catch (e) {
      if (e.code === 'ER_DUP_ENTRY') {
        return send(res, 409, {
          error: 'An account with that email already exists.'
        });
      }

      throw e;
    }
  }

  // Login
  if (method === 'POST' && pathname === '/api/auth/login') {
    const body = await readBody(req);

    const email = String(body.email || '').trim().toLowerCase();
    const password = String(body.password || '');

    const [rows] = await db.query(
      'SELECT id,full_name,email,phone,password_hash,role FROM users WHERE email=? AND is_active=1 LIMIT 1',
      [email]
    );

    if (
      !rows[0] ||
      !verifyPassword(password, rows[0].password_hash)
    ) {
      return send(res, 401, {
        error: 'Email or password is incorrect.'
      });
    }

    await createSession(rows[0].id, res);

    const {
      password_hash,
      ...safeUser
    } = rows[0];

    return send(res, 200, {
      message: 'Logged in.',
      user: safeUser
    });
  }

  // Google login
  if (method === 'POST' && pathname === '/api/auth/google') {
    const body = await readBody(req);
    const credential = String(body.credential || '');

    if (!credential) {
      return send(res, 400, {
        error: 'Google credential is missing.'
      });
    }

    try {
      const ticket = await googleClient.verifyIdToken({
        idToken: credential,
        audience: process.env.GOOGLE_CLIENT_ID
      });

      const payload = ticket.getPayload();

      if (
        !payload ||
        !payload.email ||
        payload.email_verified !== true
      ) {
        return send(res, 401, {
          error: 'Google account email is not verified.'
        });
      }

      const email = payload.email.trim().toLowerCase();

      const name = String(
        payload.name || email.split('@')[0]
      ).trim();

      const [rows] = await db.query(
        'SELECT id,full_name,email,phone,role,is_active FROM users WHERE email=? LIMIT 1',
        [email]
      );

      let user;

      if (rows[0]) {
        if (
          !rows[0].is_active ||
          rows[0].role !== 'customer'
        ) {
          return send(res, 403, {
            error: 'This account cannot use Google customer login.'
          });
        }

        user = rows[0];

      } else {
        const randomPassword = randomBytes(32).toString('hex');

        const [result] = await db.query(
          "INSERT INTO users (full_name,email,phone,password_hash,role) VALUES (?,?,NULL,?,'customer')",
          [name, email, hashPassword(randomPassword)]
        );

        user = {
          id: result.insertId,
          full_name: name,
          email,
          phone: null,
          role: 'customer'
        };
      }

      await createSession(user.id, res);

      return send(res, 200, {
        message: 'Google login successful.',
        user
      });

    } catch (error) {
      console.error('Google login error:', error.message);

      return send(res, 401, {
        error: 'Google authentication failed. Please try again.'
      });
    }
  }

  // Logout
  if (method === 'POST' && pathname === '/api/auth/logout') {
    const token = parseCookies(req.headers.cookie).gh_session;

    if (token) {
      await db.query(
        'DELETE FROM sessions WHERE token_hash=?',
        [hashToken(token)]
      );
    }

    res.setHeader(
      'Set-Cookie',
      'gh_session=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0'
    );

    return send(res, 200, {
      message: 'Logged out.'
    });
  }

  // Current logged-in user
  if (method === 'GET' && pathname === '/api/auth/me') {
    return send(res, 200, {
      user: user || null
    });
  }

 
  // Add product
  if (method === 'POST' && pathname === '/api/admin/products') {
    if (!requireAdmin(user, res)) return;

    const b = await readBody(req);

    const name = String(b.name || '').trim();
    const price = Number(b.price);
    const stock = Number(b.stockQuantity);
    const threshold = Number(b.lowStockThreshold ?? 5);
    const categoryId = Number(b.categoryId);

    if (
      !name ||
      !Number.isFinite(price) ||
      price < 0 ||
      !Number.isInteger(stock) ||
      stock < 0 ||
      !Number.isInteger(threshold) ||
      threshold < 0 ||
      !Number.isInteger(categoryId)
    ) {
      return send(res, 400, {
        error: 'Provide valid product details and minimum stock level.'
      });
    }

    const [r] = await db.query(
      `INSERT INTO products
      (category_id,name,description,price,stock_quantity,
       low_stock_threshold,image_url,sku)
       VALUES (?,?,?,?,?,?,?,?)`,
      [
        categoryId,
        name,
        String(b.description || ''),
        price,
        stock,
        threshold,
        String(b.imageUrl || ''),
        String(b.sku || '') || null
      ]
    );

    return send(res, 201, {
      message: 'Product created.',
      id: r.insertId
    });
  }

  // Edit or delete products
  const productMatch = pathname.match(
    /^\/api\/admin\/products\/(\d+)$/
  );

  if (productMatch && method === 'PUT') {
    if (!requireAdmin(user, res)) return;

    const b = await readBody(req);

    const id = Number(productMatch[1]);
    const price = Number(b.price);
    const stock = Number(b.stockQuantity);
    const threshold = Number(b.lowStockThreshold ?? 5);

    if (
      !String(b.name || '').trim() ||
      !Number.isFinite(price) ||
      price < 0 ||
      !Number.isInteger(stock) ||
      stock < 0 ||
      !Number.isInteger(threshold) ||
      threshold < 0 ||
      !Number.isInteger(Number(b.categoryId))
    ) {
      return send(res, 400, {
        error: 'Invalid product details.'
      });
    }

    const [r] = await db.query(
      `UPDATE products SET
       category_id=?,
       name=?,
       description=?,
       price=?,
       stock_quantity=?,
       low_stock_threshold=?,
       image_url=?,
       is_active=?
       WHERE id=?`,
      [
        Number(b.categoryId),
        String(b.name).trim(),
        String(b.description || ''),
        price,
        stock,
        threshold,
        String(b.imageUrl || ''),
        b.isActive === false ? 0 : 1,
        id
      ]
    );

    return send(res, r.affectedRows ? 200 : 404, {
      message: r.affectedRows
        ? 'Product updated.'
        : 'Product not found.'
    });
  }

  if (productMatch && method === 'DELETE') {
    if (!requireAdmin(user, res)) return;

    const [r] = await db.query(
      'UPDATE products SET is_active=0 WHERE id=?',
      [Number(productMatch[1])]
    );

    return send(res, r.affectedRows ? 200 : 404, {
      message: r.affectedRows
        ? 'Product hidden from the shop.'
        : 'Product not found.'
    });
  }

  // POS sales history
  if (method === 'GET' && pathname === '/api/admin/pos-sales') {
    if (!requireAdmin(user, res)) return;

    const search = String(
      url.searchParams.get('search') || ''
    ).trim();

    const from = String(
      url.searchParams.get('from') || ''
    ).trim();

    const to = String(
      url.searchParams.get('to') || ''
    ).trim();

    // Validate date filters
    const validDate = value =>
      !value || (
        /^\d{4}-\d{2}-\d{2}$/.test(value) &&
        !Number.isNaN(Date.parse(value))
      );

    if (!validDate(from) || !validDate(to)) {
      return send(res, 400, {
        error: 'Invalid date filter. Use YYYY-MM-DD.'
      });
    }

    if (from && to && from > to) {
      return send(res, 400, {
        error: 'The start date cannot be after the end date.'
      });
    }

    let sql = `
      SELECT
        o.id,
        o.order_number,
        o.customer_name,
        o.customer_phone,
        o.subtotal,
        o.discount_amount,
        o.total_amount,
        o.payment_method,
        o.payment_status,
        o.order_status,
        o.created_at,

        (
          SELECT p.transaction_reference
          FROM payments p
          WHERE p.order_id = o.id
          ORDER BY p.created_at DESC
          LIMIT 1
        ) AS payment_reference,

        (
          SELECT COUNT(*)
          FROM order_items oi
          WHERE oi.order_id = o.id
        ) AS total_items

      FROM orders o

      WHERE o.sales_channel = 'pos'
    `;

    const params = [];

    if (search) {
      sql += `
        AND (
          o.order_number LIKE ?
          OR o.customer_name LIKE ?
          OR o.customer_phone LIKE ?
        )
      `;

      const term = `%${search}%`;

      params.push(term, term, term);
    }

    if (from) {
      sql += ` AND o.created_at >= ?`;
      params.push(`${from} 00:00:00`);
    }

    if (to) {
      sql += ` AND o.created_at < DATE_ADD(?, INTERVAL 1 DAY)`;
      params.push(`${to} 00:00:00`);
    }

    sql += `
      ORDER BY o.created_at DESC
      LIMIT 300
    `;

    const [rows] = await db.query(sql, params);

    return send(res, 200, {
      sales: rows
    });
  }

  // Get details of one POS sale
  const posSaleMatch = pathname.match(
    /^\/api\/admin\/pos-sales\/(\d+)$/
  );

  if (
    method === 'GET' &&
    posSaleMatch
  ) {
    if (!requireAdmin(user, res)) return;

    const saleId = Number(posSaleMatch[1]);

    const [orders] = await db.query(
      `SELECT
        id,
        order_number,
        customer_name,
        customer_phone,
        subtotal,
        discount_amount,
        total_amount,
        payment_method,
        payment_status,
        order_status,
        created_at
       FROM orders
       WHERE id = ?
       AND sales_channel = 'pos'
       LIMIT 1`,
      [saleId]
    );

    if (!orders.length) {
      return send(res, 404, {
        error: 'POS sale not found.'
      });
    }

    const [items] = await db.query(
      `SELECT
        product_id,
        product_name,
        unit_price,
        quantity,
        line_total
       FROM order_items
       WHERE order_id = ?
       ORDER BY id ASC`,
      [saleId]
    );

    const [payments] = await db.query(
      `SELECT
        provider,
        transaction_reference,
        amount,
        status,
        created_at
       FROM payments
       WHERE order_id = ?
       ORDER BY created_at DESC`,
      [saleId]
    );

    return send(res, 200, {
      sale: orders[0],
      items,
      payments
    });
  }

  // POS sales reports
  if (method === 'GET' && pathname === '/api/admin/pos-reports') {
    if (!requireAdmin(user, res)) return;

    const params = new URLSearchParams(req.url.split('?')[1] || '');
    const from = params.get('from') || '';
    const to = params.get('to') || '';

    const validDate = value => {
      if (!value) return true;
      if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;

      const date = new Date(`${value}T00:00:00Z`);
      return date.toISOString().slice(0, 10) === value;
    };

    if (!validDate(from) || !validDate(to)) {
      return send(res, 400, {
        error: 'Invalid date. Use YYYY-MM-DD.'
      });
    }

    if (from && to && from > to) {
      return send(res, 400, {
        error: 'The start date cannot be after the end date.'
      });
    }

    let dateCondition = 'DATE(o.created_at) = CURDATE()';
    const dateValues = [];

    if (from && to) {
      dateCondition = 'DATE(o.created_at) BETWEEN ? AND ?';
      dateValues.push(from, to);
    } else if (from) {
      dateCondition = 'DATE(o.created_at) >= ?';
      dateValues.push(from);
    } else if (to) {
      dateCondition = 'DATE(o.created_at) <= ?';
      dateValues.push(to);
    }

    const [summaryRows] = await db.query(`
      SELECT
        COUNT(*) AS totalTransactions,
        COALESCE(SUM(o.total_amount), 0) AS totalSales,
        COALESCE(SUM(o.discount_amount), 0) AS totalDiscounts
      FROM orders o
      WHERE o.sales_channel = 'pos'
      AND o.payment_status = 'paid'
      AND ${dateCondition}
    `, dateValues);

    const [paymentMethods] = await db.query(`
      SELECT
        o.payment_method AS paymentMethod,
        COUNT(*) AS transactions,
        COALESCE(SUM(o.total_amount), 0) AS totalSales
      FROM orders o
      WHERE o.sales_channel = 'pos'
      AND o.payment_status = 'paid'
      AND ${dateCondition}
      GROUP BY o.payment_method
      ORDER BY totalSales DESC
    `, dateValues);

    return send(res, 200, {
      report: {
        from: from || 'today',
        to: to || 'today',
        totalTransactions: Number(summaryRows[0].totalTransactions),
        totalSales: Number(summaryRows[0].totalSales),
        totalDiscounts: Number(summaryRows[0].totalDiscounts)
      },
      paymentMethods: paymentMethods.map(method => ({
        paymentMethod: method.paymentMethod,
        transactions: Number(method.transactions),
        totalSales: Number(method.totalSales)
      }))
    });
  }

  // Record a physical shop sale through the POS
  if (method === 'POST' && pathname === '/api/admin/pos-sales') {
    if (!requireAdmin(user, res)) return;

    const b = await readBody(req);
    const items = Array.isArray(b.items) ? b.items : [];

    const customerName =
      String(b.customerName || 'Walk-in Customer').trim();

    const customerPhone =
      String(b.customerPhone || '').trim() || 'N/A';

    const paymentMethod = String(b.paymentMethod || '');
    const reference = String(b.paymentReference || '').trim();

    const discountInput = Number(b.discount || 0);

    if (!items.length) {
      return send(res, 400, {
        error: 'Add at least one product to the sale.'
      });
    }

    if (!customerName || customerName.length > 120) {
      return send(res, 400, {
        error: 'Enter a valid customer name.'
      });
    }

    if (customerPhone.length > 30) {
      return send(res, 400, {
        error: 'Customer phone number is too long.'
      });
    }

    if (!['cash', 'mpesa', 'bank_transfer'].includes(paymentMethod)) {
      return send(res, 400, {
        error: 'Select a valid payment method.'
      });
    }

    // Require the cashier to confirm that payment was received.
    if (b.paymentConfirmed !== true) {
      return send(res, 400, {
        error: 'Please confirm that payment has been received.'
      });
    }

    if (
      !Number.isFinite(discountInput) ||
      discountInput < 0
    ) {
      return send(res, 400, {
        error: 'Enter a valid discount.'
      });
    }

    if (
      ['mpesa', 'bank_transfer'].includes(paymentMethod) &&
      (!reference || reference.length > 100)
    ) {
      return send(res, 400, {
        error: 'Enter the payment transaction reference.'
      });
    }

    // Combine repeated product IDs before checking stock.
    const quantities = new Map();

    for (const item of items) {
      const id = Number(item.productId);
      const quantity = Number(item.quantity);

      if (
        !Number.isInteger(id) ||
        !Number.isInteger(quantity) ||
        id < 1 ||
        quantity < 1 ||
        quantity > 100
      ) {
        return send(res, 400, {
          error: 'One of the product quantities is invalid.'
        });
      }

      quantities.set(
        id,
        (quantities.get(id) || 0) + quantity
      );
    }

    for (const quantity of quantities.values()) {
      if (quantity > 100) {
        return send(res, 400, {
          error: 'A product quantity cannot exceed 100.'
        });
      }
    }

    const connection = await db.getConnection();

    try {
      await connection.beginTransaction();

      let subtotal = 0;
      const verifiedProducts = [];

      for (const [id, quantity] of quantities) {
        const [found] = await connection.query(
          `SELECT id,name,price,stock_quantity
           FROM products
           WHERE id=? AND is_active=1
           FOR UPDATE`,
          [id]
        );

        if (!found.length) {
          throw new Error('A selected product is unavailable.');
        }

        const product = found[0];

        if (Number(product.stock_quantity) < quantity) {
          throw new Error(
            `Not enough stock for ${product.name}.`
          );
        }

        const price = Number(product.price);
        const lineTotal = price * quantity;

        subtotal += lineTotal;

        verifiedProducts.push({
          id: product.id,
          name: product.name,
          price,
          quantity,
          lineTotal
        });
      }

      if (discountInput > subtotal) {
        throw new Error(
          'Discount cannot exceed the sale subtotal.'
        );
      }

      const discount = discountInput;
      const total = subtotal - discount;

      if (total <= 0) {
        throw new Error(
          'The sale total must be greater than zero.'
        );
      }

      const orderNumber =
        'GH' +
        Date.now().toString().slice(-10) +
        randomBytes(4).toString('hex').toUpperCase();

      const [order] = await connection.query(
        `INSERT INTO orders
        (
          order_number,
          user_id,
          customer_name,
          customer_phone,
          delivery_address,
          delivery_notes,
          subtotal,
          delivery_fee,
          total_amount,
          payment_method,
          payment_status,
          order_status,
          sales_channel,
          discount_amount
        )
        VALUES (?,NULL,?,?,NULL,NULL,?,0,?,?, 'paid','delivered','pos',?)`,
        [
          orderNumber,
          customerName,
          customerPhone,
          subtotal,
          total,
          paymentMethod,
          discount
        ]
      );

      for (const product of verifiedProducts) {
        await connection.query(
          `INSERT INTO order_items
          (order_id,product_id,product_name,unit_price,quantity,line_total)
          VALUES (?,?,?,?,?,?)`,
          [
            order.insertId,
            product.id,
            product.name,
            product.price,
            product.quantity,
            product.lineTotal
          ]
        );

        await connection.query(
          `UPDATE products
           SET stock_quantity = stock_quantity - ?
           WHERE id = ?`,
          [product.quantity, product.id]
        );
      }

      await connection.query(
        `INSERT INTO payments
        (order_id,provider,transaction_reference,amount,status)
        VALUES (?,?,?,?, 'successful')`,
        [
          order.insertId,
          paymentMethod,
          reference || null,
          total
        ]
      );

      await connection.commit();

      // Return complete receipt information to the POS frontend.
      return send(res, 201, {
        message: 'POS sale recorded successfully.',

        receipt: {
          orderNumber,
          date: new Date().toISOString(),

          businessName: 'GreenHarvest Agrovet',

          customer: {
            name: customerName,
            phone: customerPhone
          },

          items: verifiedProducts.map(product => ({
            id: product.id,
            name: product.name,
            quantity: product.quantity,
            unitPrice: product.price,
            lineTotal: product.lineTotal
          })),

          subtotal,
          discount,
          totalAmount: total,

          payment: {
            method: paymentMethod,
            reference: reference || 'N/A',
            status: 'Paid'
          }
        }
      });

    } catch (error) {
      await connection.rollback();

      return send(res, 400, {
        error: error.message
      });

    } finally {
      connection.release();
    }
  }

  // Place customer order
  if (method === 'POST' && pathname === '/api/orders') {
    if (!requireUser(user, res)) return;

    const b = await readBody(req);
    const items = Array.isArray(b.items) ? b.items : [];

    const customerName = String(
      b.customerName || user.full_name
    ).trim();

    const phone = String(
      b.phone || user.phone || ''
    ).trim();

    const address = String(
      b.deliveryAddress || ''
    ).trim();

    if (!items.length || !phone || !address) {
      return send(res, 400, {
        error: 'Your cart, phone number and delivery address are required.'
      });
    }

    const connection = await db.getConnection();

    try {
      await connection.beginTransaction();

      let subtotal = 0;
      const verified = [];

      for (const item of items) {
        const id = Number(item.productId);
        const qty = Number(item.quantity);

        if (
          !Number.isInteger(id) ||
          !Number.isInteger(qty) ||
          qty < 1 ||
          qty > 100
        ) {
          throw new Error(
            'One of the cart quantities is invalid.'
          );
        }

        const [found] = await connection.query(
          'SELECT id,name,price,stock_quantity FROM products WHERE id=? AND is_active=1 FOR UPDATE',
          [id]
        );

        if (!found[0]) {
          throw new Error(
            'A selected product is no longer available.'
          );
        }

        if (found[0].stock_quantity < qty) {
          throw new Error(
            `Not enough stock for ${found[0].name}.`
          );
        }

        const line = Number(found[0].price) * qty;

        subtotal += line;

        verified.push({
          ...found[0],
          quantity: qty,
          line
        });
      }

      const [[settings]] = await connection.query(
        "SELECT setting_value FROM business_settings WHERE setting_key='delivery_fee'"
      );

      const delivery = Number(settings?.setting_value || 0);
      const total = subtotal + delivery;

      const orderNumber =
        'GH' +
        Date.now().toString().slice(-10) +
        randomBytes(2).toString('hex').toUpperCase();

      const [order] = await connection.query(
        `INSERT INTO orders
        (order_number,user_id,customer_name,customer_phone,
        delivery_address,delivery_notes,subtotal,delivery_fee,
        total_amount,payment_method)
        VALUES (?,?,?,?,?,?,?,?,?,?)`,
        [
          orderNumber,
          user.id,
          customerName,
          phone,
          address,
          String(b.deliveryNotes || ''),
          subtotal,
          delivery,
          total,
          ['mpesa', 'cash_on_delivery', 'manual_mpesa'].includes(
            b.paymentMethod
          )
            ? b.paymentMethod
            : 'manual_mpesa'
        ]
      );

      for (const p of verified) {
        await connection.query(
          'INSERT INTO order_items (order_id,product_id,product_name,unit_price,quantity,line_total) VALUES (?,?,?,?,?,?)',
          [
            order.insertId,
            p.id,
            p.name,
            p.price,
            p.quantity,
            p.line
          ]
        );

        await connection.query(
          'UPDATE products SET stock_quantity=stock_quantity-? WHERE id=?',
          [p.quantity, p.id]
        );
      }

      await connection.query(
        'INSERT INTO payments (order_id,provider,amount,status) VALUES (?,?,?,?)',
        [order.insertId, 'manual', total, 'pending']
      );

      await connection.commit();

      return send(res, 201, {
        message: 'Order placed.',
        orderNumber,
        totalAmount: total
      });

    } catch (e) {
      await connection.rollback();

      return send(res, 400, {
        error: e.message
      });

    } finally {
      connection.release();
    }
  }

  // Customer order history
  if (method === 'GET' && pathname === '/api/orders/mine') {
    if (!requireUser(user, res)) return;

    const [rows] = await db.query(
      'SELECT id,order_number,total_amount,payment_status,order_status,created_at FROM orders WHERE user_id=? ORDER BY created_at DESC',
      [user.id]
    );

    return send(res, 200, {
      orders: rows
    });
  }

  // Admin dashboard statistics
  if (
    method === 'GET' &&
    pathname === '/api/admin/dashboard-stats'
  ) {
    if (!requireAdmin(user, res)) return;

    const [rows] = await db.query(`
      SELECT
        (
          SELECT COUNT(*)
          FROM products
          WHERE is_active = 1
        ) AS totalProducts,

        (
          SELECT COUNT(*)
          FROM orders
        ) AS totalOrders,

        (
          SELECT COUNT(*)
          FROM users
          WHERE role = 'customer'
          AND is_active = 1
        ) AS totalCustomers,

        (
          SELECT COALESCE(SUM(total_amount), 0)
          FROM orders
          WHERE payment_status = 'paid'
        ) AS totalSales
    `);

    return send(res, 200, {
      stats: rows[0]
    });
  }

    // Admin inventory alerts
  if (method === 'GET' && pathname === '/api/admin/inventory-alerts') {
    if (!requireAdmin(user, res)) return;

    const [products] = await db.query(`
      SELECT
        id,
        name,
        sku,
        stock_quantity,
        low_stock_threshold,
        CASE
          WHEN stock_quantity = 0 THEN 'out_of_stock'
          ELSE 'low_stock'
        END AS alert_type
      FROM products
      WHERE is_active = 1
      AND stock_quantity <= low_stock_threshold
      ORDER BY stock_quantity ASC, name ASC
    `);

    const outOfStock = products.filter(
      product => Number(product.stock_quantity) === 0
    ).length;

    const lowStock = products.filter(
      product => Number(product.stock_quantity) > 0
    ).length;

    return send(res, 200, {
      summary: {
        outOfStock,
        lowStock,
        totalAlerts: products.length
      },
      products
    });
  }

  // Admin product restocking
  const restockMatch = pathname.match(
    /^\/api\/admin\/products\/(\d+)\/restock$/
  );

  if (method === 'POST' && restockMatch) {
    if (!requireAdmin(user, res)) return;

    const productId = Number(restockMatch[1]);
    const b = await readBody(req);

    const quantity = Number(b.quantity);
    const notes = String(b.notes || '').trim();

    if (
      !Number.isSafeInteger(productId) ||
      productId < 1 ||
      !Number.isInteger(quantity) ||
      quantity < 1 ||
      quantity > 1000000 ||
      notes.length > 255
    ) {
      return send(res, 400, {
        error: 'Enter a valid restocking quantity and notes.'
      });
    }

    const connection = await db.getConnection();

    try {
      await connection.beginTransaction();

      const [products] = await connection.query(
        `SELECT id, name, stock_quantity
         FROM products
         WHERE id = ? AND is_active = 1
         FOR UPDATE`,
        [productId]
      );

      if (!products.length) {
        await connection.rollback();

        return send(res, 404, {
          error: 'Product not found or is inactive.'
        });
      }

      const product = products[0];

      const previousStock = Number(product.stock_quantity);
      const newStock = previousStock + quantity;

      if (
        !Number.isSafeInteger(newStock) ||
        newStock > 4294967295
      ) {
        throw new Error(
          'The resulting stock quantity is too large.'
        );
      }

      await connection.query(
        `UPDATE products
         SET stock_quantity = ?
         WHERE id = ?`,
        [newStock, productId]
      );

      await connection.query(
        `INSERT INTO inventory_movements
        (
          product_id,
          user_id,
          movement_type,
          quantity,
          previous_stock,
          new_stock,
          notes
        )
        VALUES (?, ?, 'restock', ?, ?, ?, ?)`,
        [
          productId,
          user.id,
          quantity,
          previousStock,
          newStock,
          notes || null
        ]
      );

      await connection.commit();

      return send(res, 200, {
        message: 'Stock restocked successfully.',
        product: {
          id: productId,
          name: product.name,
          quantityReceived: quantity,
          previousStock,
          newStock
        }
      });

    } catch (error) {
      await connection.rollback();

      console.error('Restocking error:', error);

      return send(res, 400, {
        error: error.message || 'Unable to restock product.'
      });

    } finally {
      connection.release();
    }
  }

  // Admin order management
  if (method === 'GET' && pathname === '/api/admin/orders') {
    if (!requireAdmin(user, res)) return;

    const [rows] = await db.query(
      'SELECT id,order_number,customer_name,customer_phone,total_amount,payment_status,order_status,created_at FROM orders ORDER BY created_at DESC LIMIT 200'
    );

    return send(res, 200, {
      orders: rows
    });
  }

  // Update order status
  const orderMatch = pathname.match(
    /^\/api\/admin\/orders\/(\d+)\/status$/
  );

  if (orderMatch && method === 'PATCH') {
    if (!requireAdmin(user, res)) return;

    const b = await readBody(req);

    const allowed = [
      'pending',
      'confirmed',
      'processing',
      'ready',
      'dispatched',
      'delivered',
      'cancelled'
    ];

    if (!allowed.includes(b.status)) {
      return send(res, 400, {
        error: 'Invalid order status.'
      });
    }

    const [r] = await db.query(
      'UPDATE orders SET order_status=? WHERE id=?',
      [b.status, Number(orderMatch[1])]
    );

    return send(res, r.affectedRows ? 200 : 404, {
      message: r.affectedRows
        ? 'Order status updated.'
        : 'Order not found.'
    });
  }

  return send(res, 404, {
    error: 'API endpoint not found.'
  });
}

// Main server
const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, 'http://localhost');

    if (url.pathname.startsWith('/api/')) {
      return await api(req, res, url);
    }

    let requested = decodeURIComponent(
      url.pathname === '/' ? '/index.html' : url.pathname
    );

    const filePath = path.resolve(ROOT, '.' + requested);

    if (
      !filePath.startsWith(ROOT + path.sep) &&
      filePath !== ROOT
    ) {
      return send(res, 403, {
        error: 'Forbidden'
      });
    }

    fs.readFile(filePath, (err, data) => {
      if (err) {
        return send(res, 404, {
          error: 'Page or file not found.'
        });
      }

      res.writeHead(200, {
        'Content-Type':
          MIME[path.extname(filePath).toLowerCase()] ||
          'application/octet-stream'
      });

      res.end(data);
    });

  } catch (error) {
    console.error(error);

    if (!res.headersSent) {
      send(res, 500, {
        error: 'Server error. Check the terminal for details.'
      });
    }
  }
});

server.listen(PORT, () => {
  console.log(
    `GreenHarvest server running at http://localhost:${PORT}`
  );
});
